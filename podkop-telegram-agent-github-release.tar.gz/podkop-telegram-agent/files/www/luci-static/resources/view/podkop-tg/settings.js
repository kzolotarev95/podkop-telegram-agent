'use strict';

var BOT_VERSION = 'v1.0.8';

'require view';
'require form';
'require uci';
'require fs';
'require ui';
'require poll';

function serviceStatus() {
    return fs.exec('/etc/init.d/podkop-telegram-agent', [ 'status' ]).then(function(res) {
        return res.code === 0;
    }).catch(function() {
        return false;
    });
}

function serviceAction(action) {
    return fs.exec('/etc/init.d/podkop-telegram-agent', [ action ]).then(function(res) {
        if (res.code !== 0)
            throw new Error(res.stderr || res.stdout || _('Ошибка выполнения команды'));
        ui.addNotification(null, E('p', _('Команда выполнена: ') + action));
    }).catch(function(err) {
        ui.addNotification(null, E('p', _('Ошибка выполнения: ') + (err.message || err)), 'danger');
    });
}


function stripAnsi(text) {
    return (text || '').replace(/\[[0-?]*[ -/]*[@-~]/g, '');
}

function copyLogsToClipboard(textarea, text) {
    var done = function() {
        ui.addNotification(null, E('p', _('Логи скопированы в буфер обмена')));
    };

    if (navigator.clipboard && navigator.clipboard.writeText) {
        return navigator.clipboard.writeText(text).then(done).catch(function() {
            textarea.focus();
            textarea.select();
            document.execCommand('copy');
            done();
        });
    }

    textarea.focus();
    textarea.select();
    document.execCommand('copy');
    done();
}

function showLogsModal(lines, text) {
    var textarea = E('textarea', {
        'readonly': 'readonly',
        'wrap': 'off',
        'style': 'width: 100%; min-height: 55vh; max-height: 65vh; overflow: auto; box-sizing: border-box; font-family: monospace; white-space: pre; padding: 1em; border: 1px solid #ccc; border-radius: 6px; resize: vertical;'
    }, text || _('Логи пустые'));

    ui.showModal(_('📄 Посмотреть логи'), [
        E('p', {}, _('Показан полный logread без фильтра, последние %s строк.').format(lines)),
        textarea,
        E('div', { 'class': 'right', 'style': 'margin-top: 1em;' }, [
            E('button', {
                'class': 'btn cbi-button cbi-button-action',
                'click': function(ev) {
                    ev.preventDefault();
                    return copyLogsToClipboard(textarea, text || '');
                }
            }, _('Копировать')),
            ' ',
            E('button', {
                'class': 'btn cbi-button cbi-button-reset',
                'click': function(ev) {
                    ev.preventDefault();
                    ui.hideModal();
                }
            }, _('Закрыть'))
        ])
    ]);
}

function showAllLogs() {
    return uci.load('podkop_tg').then(function() {
        var lines = parseInt(uci.get('podkop_tg', 'main', 'log_lines') || '200', 10);
        if (!isFinite(lines) || lines < 200)
            lines = 200;
        if (lines > 1000)
            lines = 1000;

        ui.showModal(_('📄 Посмотреть логи'), [
            E('p', {}, _('Загружаю полный logread, последние %s строк…').format(lines)),
            E('div', { 'class': 'spinning' }, _('Пожалуйста, подождите')),
            E('div', { 'class': 'right', 'style': 'margin-top: 1em;' }, [
                E('button', {
                    'class': 'btn cbi-button cbi-button-reset',
                    'click': function(ev) {
                        ev.preventDefault();
                        ui.hideModal();
                    }
                }, _('Закрыть'))
            ])
        ]);

        return fs.exec('/usr/bin/podkop-telegram-agent-logread', [ String(lines) ]).then(function(res) {
            var text = stripAnsi(res.stdout || res.stderr || _('Логи пустые'));
            showLogsModal(lines, text);
        }).catch(function(err) {
            ui.showModal(_('📄 Посмотреть логи'), [
                E('p', {}, _('Не удалось прочитать логи: ') + (err.message || err)),
                E('div', { 'class': 'right', 'style': 'margin-top: 1em;' }, [
                    E('button', {
                        'class': 'btn cbi-button cbi-button-reset',
                        'click': function(ev) {
                            ev.preventDefault();
                            ui.hideModal();
                        }
                    }, _('Закрыть'))
                ])
            ]);
        });
    });
}

function systemHostname() {
    return fs.exec('/bin/hostname', []).then(function(res) {
        var name = (res.stdout || '').trim();
        return name || 'openwrt';
    }).catch(function() {
        return 'openwrt';
    });
}

function badRouterName(name) {
    return !name || /^(openwrt|o__nwrt|o--nwrt|o_nwrt|localhost|router)$/i.test(String(name));
}

function routerNameValue(section_id, hostname) {
    var cur = uci.get('podkop_tg', section_id, 'router_name');
    return badRouterName(cur) ? hostname : cur;
}

return view.extend({
    load: function() {
        return Promise.all([
            uci.load('podkop_tg'),
            serviceStatus(),
            systemHostname()
        ]);
    },

    render: function(data) {
        var running = data[1];
        var hostname = data[2] || 'openwrt';
        var m, s, o;

        m = new form.Map('podkop_tg', _('Podkop Telegram'), E('span', {}, [
            _('Telegram - модуль для Podkop/OpenWrt. Агент работает отдельной службой и управляется через UCI-конфиг /etc/config/podkop_tg.'),
            E('br'),
            _('спасибо большое за данный модуль начинающему скриптеру '),
            E('a', {
                'href': 'https://t.me/kzolotarev95',
                'target': '_blank',
                'rel': 'noopener noreferrer',
                'style': 'color: #e74c3c; font-weight: 700;'
            }, 'by zks95'),
            E('br'),
            E('small', { 'style': 'opacity:.72; font-size:11px;' }, _('Версия: Podkop Telegram Agent ') + BOT_VERSION)
        ]));

        s = m.section(form.NamedSection, 'main', 'bot', _('Настройки бота'));
        s.addremove = false;
        s.anonymous = true;

        o = s.option(form.DummyValue, '_state', _('Статус агента'));
        o.rawhtml = true;
        o.cfgvalue = function() {
            return running
                ? '<strong style="color:green">ЗАПУЩЕН</strong>'
                : '<strong style="color:red">ОСТАНОВЛЕН</strong>';
        };

        o = s.option(form.Flag, 'enabled', _('Включить агента'));
        o.default = '1';
        o.rmempty = false;

        o = s.option(form.Value, 'token', _('Токен Telegram-бота'));
        o.password = true;
        o.placeholder = '123456789:AAxxxxxxxxxxxxxxxxxxxxxxxxxxxx';
        o.rmempty = false;

        o = s.option(form.Value, 'chat_id', _('User ID администратора бота'));
        o.placeholder = _('Оставьте пустым, сохраните и отправьте боту /start');
        o.rmempty = true;
        o.description = _('Один или несколько User ID администратора(-ов) Telegram-бота. Для получения User ID используйте @userinfobot или команду \'/myid\' в боте. Несколько ID можно указать через пробел, запятую или точку с запятой.');

        o = s.option(form.DynamicList, 'chat_ids', _('Дополнительные User ID администраторов'));
        o.placeholder = '111111111';
        o.rmempty = true;
        o.description = _('Дополнительные User ID Telegram-администраторов. Каждый пользователь может узнать свой ID командой /myid.');

        o = s.option(form.Value, 'router_name', _('Имя роутера'));
        o.placeholder = hostname;
        o.default = hostname;
        o.rmempty = false;
        o.cfgvalue = function(section_id) {
            return routerNameValue(section_id, hostname);
        };
        o.validate = function(section_id, value) {
            if (value && !/^[\x21-\x7E]+$/.test(value))
                return _('Имя роутера используется как один аргумент команды Telegram. Разрешены латиница, цифры и ASCII-спецсимволы без пробелов: _, -, ., @, # и т.п.');
            return true;
        };
        o.description = _('Имя используется в Telegram-командах как адрес роутера, например /status router_1. При первом открытии подставляется hostname OpenWrt. Допустимы латиница, цифры и ASCII-спецсимволы без пробелов.');

        o = s.option(form.ListValue, 'bot_mode', _('Режим Telegram-панели'));
        o.value('standalone', _('Один роутер / обычный режим'));
        o.value('panel', _('Главная панель нескольких роутеров'));
        o.value('worker', _('Worker-роутер без общих ответов'));
        o.default = 'standalone';
        o.rmempty = false;
        o.description = _('Для одного Telegram token на нескольких роутерах: на одном роутере выберите «Главная панель», на остальных — «Worker». Тогда /start и общие кнопки отвечает только панель, а worker отвечает только на команды со своим именем роутера.');

        o = s.option(form.Value, 'router_list', _('Роутеры в Telegram-панели'));
        o.placeholder = hostname + ' ROUTER2 ROUTER3 ROUTER4';
        o.rmempty = true;
        o.size = 96;
        o.description = _('Список имён роутеров для выбора кнопками в режиме панели. Поле расширено для 10–20 роутеров. Разделители: пробел, запятая или точка с запятой. Если worker-роутер переименован, добавьте старое имя в поле «Алиасы старых имён роутера» на этом worker, либо обновите имя здесь.');
        o.validate = function(section_id, value) {
            if (value && !/^[A-Za-z0-9_.@#:-]+([,;\s]+[A-Za-z0-9_.@#:-]+)*$/.test(value))
                return _('Используйте имена роутеров без пробелов внутри. Разделители: пробел, запятая или точка с запятой.');
            return true;
        };

        o = s.option(form.Value, 'router_aliases', _('Алиасы старых имён роутера'));
        o.placeholder = 'old-router-name rax';
        o.rmempty = true;
        o.size = 96;
        o.description = _('Необязательно. Нужны после переименования worker-роутера: бот будет отвечать и на старое имя из кнопок панели. Это помогает, если в поле «Роутеры в Telegram-панели» на главном роутере ещё осталось старое имя.');
        o.validate = function(section_id, value) {
            if (value && !/^[A-Za-z0-9_.@#:-]+([,;\s]+[A-Za-z0-9_.@#:-]+)*$/.test(value))
                return _('Используйте имена без пробелов внутри. Разделители: пробел, запятая или точка с запятой.');
            return true;
        };

        o = s.option(form.Flag, 'panel_send_header_on_actions', _('Картинка перед статусом/отчётом/помощью'));
        o.default = '1';
        o.rmempty = false;
        o.description = _('Если включено, при нажатии Статус, Отчёт и Помощь сначала отправляется картинка-шапка, затем текст команды.');

        o = s.option(form.Flag, 'header_image_enabled', _('Картинка-шапка над кнопками'));
        o.default = '1';
        o.rmempty = false;
        o.description = _('Если включено и файл картинки существует, бот отправляет картинку над главным меню с кнопками. Поддерживаются JPG/PNG/WebP. Если файла нет, бот работает как раньше.');

        o = s.option(form.Value, 'header_image_path', _('Путь к картинке-шапке'));
        o.placeholder = '/etc/podkop-telegram-agent/header.jpg';
        o.default = '/etc/podkop-telegram-agent/header.jpg';
        o.rmempty = false;
        o.description = _('Загрузите картинку на роутер по SSH/SCP, например: scp header.jpg root@192.168.2.1:/etc/podkop-telegram-agent/header.jpg. После замены картинки отправьте боту /start.');
        o.validate = function(section_id, value) {
            if (value && !/^\/.+\.(png|jpg|jpeg|webp)$/i.test(value))
                return _('Укажите абсолютный путь к файлу .png/.jpg/.jpeg/.webp, например /etc/podkop-telegram-agent/header.jpg');
            return true;
        };

        o = s.option(form.Value, 'podkop_section', _('Секция Podkop'));
        o.placeholder = 'main';
        o.default = 'main';
        o.rmempty = false;
        o.description = _('Секция по умолчанию для команды /update. Если в /update не указать секцию явно, vless/ss/trojan-ссылка будет загружена сюда. В отчёте эта секция помечается как «по умолчанию».');

        s = m.section(form.NamedSection, 'main', 'bot', _('Мониторинг и уведомления'));
        s.addremove = false;
        s.anonymous = true;

        o = s.option(form.Value, 'poll_timeout', _('Таймаут Telegram polling, сек'));
        o.datatype = 'uinteger';
        o.default = '10';
        o.rmempty = false;
        o.description = _('Чем меньше значение, тем быстрее приходят уведомления о падении. Рекомендуется 5–10 секунд.');

        o = s.option(form.Value, 'check_interval', _('Интервал проверки, сек'));
        o.datatype = 'uinteger';
        o.default = '10';
        o.rmempty = false;

        o = s.option(form.Value, 'foreign_hold_seconds', _('Удержание чужой команды, сек'));
        o.datatype = 'uinteger';
        o.default = '90';
        o.rmempty = false;
        o.description = _('Для нескольких роутеров в одном Telegram-боте: команда с чужим именем роутера не подтверждается сразу, чтобы нужный роутер успел её забрать. Если нужный роутер offline, очередь Telegram будет разблокирована после этого времени.');

        o = s.option(form.Value, 'log_lines', _('Количество строк логов'));
        o.datatype = 'uinteger';
        o.default = '200';
        o.rmempty = false;
        o.description = _('Для кнопки «📄 Посмотреть логи» и команды /logs. Если указано меньше 200, кнопка всё равно покажет минимум 200 строк.');

        o = s.option(form.Value, 'ping_host', _('Хост для проверки пинга'));
        o.placeholder = '1.1.1.1';
        o.default = '1.1.1.1';
        o.rmempty = false;

        o = s.option(form.Flag, 'alerts', _('Мгновенные уведомления'));
        o.default = '1';
        o.rmempty = false;
        o.description = _('Отправлять уведомление в Telegram, если Podkop или sing-box выключился/упал, и когда работа восстановилась.');

        o = s.option(form.Flag, 'daily_report', _('Ежедневный отчёт'));
        o.default = '1';
        o.rmempty = false;

        o = s.option(form.Value, 'daily_report_time', _('Время ежедневного отчёта'));
        o.placeholder = '09:00';
        o.default = '09:00';
        o.rmempty = false;
        o.description = _('Формат HH:MM, например 09:00. Отчёт отправляется один раз в день после наступления указанного времени, даже если агент был занят polling или перезапущен.');
        o.validate = function(section_id, value) {
            if (!/^([01]?\d|2[0-3]):[0-5]\d$/.test(value || ''))
                return _('Укажите время в формате HH:MM, например 09:00 или 21:30.');
            return true;
        };

        o = s.option(form.Flag, 'daily_backup', _('Отправлять backup OpenWrt с ежедневным отчётом'));
        o.default = '1';
        o.rmempty = false;
        o.description = _('Создаёт архив штатной командой sysupgrade -b и отправляет его файлом в Telegram после ежедневного отчёта. Внимание: backup содержит чувствительные настройки, ключи и токены. Включайте только для доверенного чата.');

        s = m.section(form.NamedSection, 'main', 'bot', _('Управление сервисом'));
        s.addremove = false;
        s.anonymous = true;

        o = s.option(form.Button, '_restart', _('Перезапустить агент'));
        o.inputstyle = 'apply';
        o.onclick = function() {
            return m.save().then(function() {
                return serviceAction('restart');
            });
        };

        o = s.option(form.Button, '_viewlogs', _('📄 Посмотреть логи'));
        o.inputstyle = 'action';
        o.description = _('Открывает полный logread без фильтра: podkop, sing-box, telegram-agent, dnsmasq, uhttpd и остальные системные строки.');
        o.onclick = function() {
            return showAllLogs();
        };

        o = s.option(form.Button, '_start', _('Запустить агент'));
        o.inputstyle = 'save';
        o.onclick = function() {
            return m.save().then(function() {
                return serviceAction('start');
            });
        };

        o = s.option(form.Button, '_stop', _('Остановить агент'));
        o.inputstyle = 'reset';
        o.onclick = function() {
            return serviceAction('stop');
        };

        poll.add(function() {
            return serviceStatus().then(function(isRunning) {
                var node = document.querySelector('[data-name="_state"] .cbi-value-field');
                if (node)
                    node.innerHTML = isRunning
                        ? '<strong style="color:green">ЗАПУЩЕН</strong>'
                        : '<strong style="color:red">ОСТАНОВЛЕН</strong>';
            });
        });

        return m.render();
    }
});
