## v1.0.26 - router-name rollback/fix
- Visible version set back to `Podkop Telegram Agent v1.0.8`.
- Router name auto-fill fixed: `NanoPiR3S -> nanopir3s`, `RAX1 -> rax1`.
- Hostname is read from `/proc/sys/kernel/hostname` first.
- Broken old auto-filled names like `n_no_i` and `r_x1` are repaired during install.

# v1.0.14

- Fixed parental-control button IP parsing: `192.168.x.x` is no longer corrupted into `2.168.x.x`.
- Added automatic repair for old saved bad rules/manual blocks like `2.168.2.212` -> `192.168.2.212`.
- Rebuilds firewall rules with the corrected IP before applying blocks.
- Visible bot version remains `Podkop Telegram Agent v1.0.7`.

# v1.0.12

- Added `📌 Активные блокировки ROUTER` button in the device access panel.
- Replaced `🔙 Меню` with `🔙 Назад` in the device access panel.
- Added `/accessblocked ROUTER` command to show currently blocked devices separately.
- Visible bot version remains `Podkop Telegram Agent v1.0.7`.

# v1.0.8

- Added Podkop URLTest/VLESS panel in Telegram.
- New button: `🔗 URLTest / VLESS`.
- New commands: `/urltest`, `/urlhelp`, `/urlping`, `/urluse`, `/urlteston`, `/urladd`, `/urldel`, `/urlapply`.
- Bot lists VLESS/Proxy links from `/etc/config/podkop` without editing sing-box config directly.
- Supports `urltest_proxy_links`, `selector_proxy_links` and single `proxy_string`.
- Added TCP host:port checks for URLTest/VLESS servers.
- Applying changes is done via UCI and Podkop restart, so it remains friendly with Podkop.

# v1.0.7

- Access-device menu cleanup: only command help + back button, now in one row.
- Visible Telegram bot version set to `Podkop Telegram Agent v1.0.5`.
- Bot version is shown in `/status` and `/report`.
- Removed the extra start-menu hint text about pressing help.

# v1.0.6

- Fixed device access blocking for Podkop/TProxy traffic by adding high-priority prerouting rules.
- Router reboot now uses OpenWrt ubus reboot with /sbin/reboot fallback.
- Visible Telegram version set to `Podkop Telegram Agent v1.0.4`.

# Release notes

## v1.0.5

- Cleaned device access Telegram UI: removed command buttons from the keyboard and left a single `📘 Помощь по командам ROUTER` button.
- Added automatic header image before new action panels.
- Changed Restart button into a mode menu: `Reboot Podkop` and `Reboot Router` with confirmation.
- Added visible bot version in Telegram.
- Added Podkop updater button/command using itdoginfo/podkop install script.


Current package includes:
- Multi-router panel/worker mode.
- Fixed worker update holding to avoid duplicate Telegram messages.
- Header image manual multipart upload.
- Header image without caption.
- Donate button removed from main keyboard.
- Extended report with system info.
- LuCI 403 permissions fix.
- Red clickable by zks95 link in LuCI.
- Backup scripts without token.

Always check logs:

```sh
logread -e podkop-telegram-agent | tail -n 160
logread -e podkop | tail -n 80
logread -e sing-box | tail -n 80
```


## Device access / parental control

Added Telegram commands for device access control by static IPv4 address. The bot can block TV boxes, consoles or other devices by schedule using OpenWrt firewall (`nft`, fallback `iptables`).

Examples:

```sh
/access ROUTER
/accessadd ROUTER tv 192.168.1.50 14:00-20:00 mon-fri
/accessblock ROUTER tv
/accessunblock ROUTER tv
/accessdel ROUTER tv
/accessapply ROUTER
```

Use static DHCP leases for controlled devices so their IP addresses do not change.


## v1.0.4

Device access / parental control updated:
- OpenWrt 24/25 compatible firewall backend: nft/firewall4 first, iptables fallback.
- Separate table `inet podkop_tg_access`; PodkopTable and sing-box config are not modified.
- Added `/accesshelp ROUTER` with examples directly in Telegram.
- Added access quick keyboard: `/access`, `/accesshelp`, `/accessapply`, `/accesson`, `/accessoff`.
- Optional MAC support: auto-detect from DHCP/static lease or pass manually.
- Supports schedules crossing midnight, for example `22:00-07:00 all`.

Always check logs:

```sh
logread -e podkop-telegram-agent | tail -n 160
logread -e podkop | tail -n 80
logread -e sing-box | tail -n 80
```

## v1.0.9

- Added live static DHCP device list in the “🚫 Доступ устройств” section.
- Shows hostname, MAC address(es), IPv4 and current DHCP lease status.
- Added per-device buttons by IP address to open an edit card.
- Added quick schedule buttons: weekdays 14:00–20:00 and night 22:00–07:00.
- Added manual block/unblock and delete schedule buttons for each device.
- Added `/accessdevice` and `/accessset` commands for IP-based editing.

## v1.0.11

- Fixed device access control for traffic that could still pass after block.
- Added stronger early nft prerouting rules before Podkop/TProxy.
- Added INPUT/FORWARD guards for router/DNS and normal routed traffic.
- Added MAC-based guards for IPv6 and multi-MAC static DHCP devices.
- Added best-effort conntrack/flow cleanup so blocks apply faster.
- Bot-visible version remains: Podkop Telegram Agent v1.0.7.


## v1.0.13 fix
- Видимая версия в Telegram: `Podkop Telegram Agent v1.0.7`.
- Кнопка `🚫 Доступ устройств` переименована в `👨‍👩‍👧 Родительский Контроль`.
- Раздел активных блокировок теперь показывает только реально заблокированные устройства.
- Усилена блокировка: добавлены nft bridge и netdev ingress правила поверх ранних inet pre-Podkop/TProxy правил.


## v1.10.10

- Added quiet-hours status text: `23:00-08:00, отложить до утра, сейчас активно/сейчас не активно`.
- Added LuCI fields `alert_quiet_hours`, `alert_quiet_start`, `alert_quiet_end`, `alert_quiet_mode`.
- Automatic alerts are queued or suppressed during quiet hours; manual Telegram commands and daily report are not blocked.


## v1.10.11 Help Button Output Fix

- Кнопка `❓ Помощь` и команда `/help` теперь отправляют текстовый список команд частями без HTML parse_mode.
- Картинка-шапка для Help отключена, чтобы не было ситуации «пришла только картинка, текста нет».
- Добавлены логи `/tmp/podkop_tg_help_v11011.log` и `/tmp/podkop_tg_help_v11011_text.txt`.
