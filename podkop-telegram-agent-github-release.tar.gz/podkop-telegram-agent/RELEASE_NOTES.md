## v1.0.34 - force help text

- Fixed `❓ Помощь` and `/help`: command list is sent as text again.
- Suppressed header image for Help only.
- Added `/tmp/podkop_tg_help_v134.log` for Telegram API response diagnostics.
- Visible version remains `Podkop Telegram Agent v1.0.9`.
