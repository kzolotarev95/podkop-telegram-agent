# Release notes

Current package includes:
- Multi-router panel/worker mode.
- Fixed worker update holding to avoid duplicate Telegram messages.
- Header image manual multipart upload.
- Header image without caption.
- Donate button removed from main keyboard.
- Extended report with system info.
- LuCI 403 permissions fix.
- Red clickable by zks95 link in LuCI.
- Backup scripts without token.

Always check logs:

```sh
logread -e podkop-telegram-agent | tail -n 160
logread -e podkop | tail -n 80
logread -e sing-box | tail -n 80
```
