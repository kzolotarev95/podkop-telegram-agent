# podkop-telegram-agent hotfix v1.0.34

Latest fix: v1.0.34 — force Help button text.

Visible interface version: **Podkop Telegram Agent v1.0.9**

This hotfix patches an already installed podkop-telegram-agent and fixes `❓ Помощь` / `/help` so the command list is sent as text, while `/start` keeps the image/menu behavior.
