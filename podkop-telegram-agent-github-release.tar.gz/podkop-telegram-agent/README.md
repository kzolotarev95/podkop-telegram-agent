# podkop-telegram-agent v1.0.32 hotfix

Latest fix: v1.0.32 — Quiet hours for night notifications.

Visible version after patch: **Podkop Telegram Agent v1.0.9**.

This archive is a hotfix package for installed v1.0.31/v1.0.30 builds. It patches the installed router files in place and preserves `/etc/config/podkop_tg`.
