# podkop-telegram-agent

Telegram-модуль для Podkop/OpenWrt.

Агент работает отдельной службой OpenWrt, управляется через UCI-конфиг:

```sh
/etc/config/podkop_tg
```

Веб-морда LuCI: **Services → Podkop Telegram**.

## Возможности

- Telegram-панель для одного или нескольких роутеров.
- Режимы:
  - `standalone` — один роутер.
  - `panel` — главный роутер с Telegram-панелью и выбором роутеров.
  - `worker` — второй/третий роутер, который отвечает только на команды своего имени.
- Команды `/status`, `/report`, `/diag`, `/logs`, `/restart`, `/backup`.
- Расширенный отчёт: температура, RAM, SWAP, overlay/flash, модель, OpenWrt, kernel, Podkop, sing-box, WAN, Wi-Fi, DHCP/Wi-Fi клиенты.
- Уведомления о WAN/Internet DOWN, восстановлении, reboot, Podkop/sing-box событиях.
- Очередь уведомлений: если интернет упал и Telegram недоступен, уведомления уйдут после восстановления.
- Картинка-шапка меню: `/etc/podkop-telegram-agent/header.jpg`.
- LuCI-модуль с настройками.
- Backup OpenWrt через `sysupgrade -b`.

## Зависимости

Минимально:

```sh
opkg update
opkg install curl jq ca-bundle unzip tar gzip
```

Для расширенного отчёта с Wi-Fi-информацией:

```sh
opkg install iwinfo
```

Для LuCI-кнопок и веб-морды:

```sh
opkg install rpcd-mod-file
```

Если на чистом роутере нет LuCI:

```sh
opkg install luci
/etc/init.d/uhttpd enable
/etc/init.d/uhttpd restart
```

Установщик `install.sh` сам попробует поставить `curl`, `jq`, `ca-bundle`, `rpcd-mod-file` и `iwinfo`, если они доступны через `opkg`.

## Установка с нуля из архива

Скопировать архив на роутер:

```sh
scp podkop-telegram-agent-github-release.zip root@192.168.2.1:/tmp/
```

На роутере:

```sh
opkg update
opkg install curl jq ca-bundle unzip tar gzip rpcd-mod-file iwinfo

cd /tmp
rm -rf /tmp/podkop-telegram-agent

unzip -o /tmp/podkop-telegram-agent-github-release.zip -d /tmp
cd /tmp/podkop-telegram-agent

ash install.sh --yes
```

Настроить UCI:

```sh
uci set podkop_tg.main.enabled='1'
uci set podkop_tg.main.token='TELEGRAM_BOT_TOKEN'
uci set podkop_tg.main.chat_id='5361341623'
uci set podkop_tg.main.router_name='WBR3000UAX'
uci set podkop_tg.main.podkop_section='main'
uci commit podkop_tg

/etc/init.d/podkop-telegram-agent enable
/etc/init.d/podkop-telegram-agent restart
```

Проверка:

```sh
/etc/init.d/podkop-telegram-agent status
uci show podkop_tg | sed "s/token='[^']*'/token='***'/"
logread -e podkop-telegram-agent | tail -n 120
logread -e podkop | tail -n 80
logread -e sing-box | tail -n 80
```

## Установка с передачей параметров сразу

```sh
ash install.sh --yes \
  --token 'TELEGRAM_BOT_TOKEN' \
  --chat-id '5361341623' \
  --router-name 'WBR3000UAX' \
  --podkop-section 'main'
```

## Multi-router режим

Один роутер должен быть `panel`, остальные `worker`.

На главном роутере:

```sh
uci set podkop_tg.main.bot_mode='panel'
uci set podkop_tg.main.router_name='WBR3000UAX'
uci set podkop_tg.main.router_list='WBR3000UAX AX3000T'
uci commit podkop_tg
/etc/init.d/podkop-telegram-agent restart
```

На втором роутере:

```sh
uci set podkop_tg.main.bot_mode='worker'
uci set podkop_tg.main.router_name='AX3000T'
uci set podkop_tg.main.router_list='WBR3000UAX AX3000T'
uci commit podkop_tg
/etc/init.d/podkop-telegram-agent restart
```

Важно: если два роутера с одним Telegram token будут в режиме `panel`, будут дубли сообщений.

## Telegram-команды

```text
/start
/status ROUTER
/report ROUTER
/diag ROUTER
/health ROUTER
/logs ROUTER
/logs ROUTER 500
/logs ROUTER runtime
/logs ROUTER errors
/logs ROUTER singbox
/logs ROUTER podkop
/restart ROUTER
/backup ROUTER
/testreport ROUTER
/header ROUTER
/myid
/help
```

## Backup бота без токена

Чтобы сделать backup установленного бота со всеми настройками, но без Telegram token:

```sh
ash scripts/backup-no-token.sh
```

Архив появится в `/tmp`:

```sh
ls -lh /tmp/podkop-telegram-agent-backup-no-token-*.tar.gz
```

Проверить, что token пустой:

```sh
tar -xOzf /tmp/podkop-telegram-agent-backup-no-token-*.tar.gz ./etc/config/podkop_tg | grep token
```

## Восстановление backup без токена на чистом роутере

На новом роутере:

```sh
opkg update
opkg install curl jq ca-bundle unzip tar gzip rpcd-mod-file iwinfo

cd /
tar -xzpf /tmp/podkop-telegram-agent-backup-no-token-*.tar.gz

chmod 0755 /usr/bin/podkop-telegram-agent
chmod 0755 /usr/bin/podkop-telegram-agent-logread
chmod 0755 /etc/init.d/podkop-telegram-agent
chmod 0644 /etc/config/podkop_tg
chmod 0644 /usr/share/luci/menu.d/luci-app-podkop-tg.json 2>/dev/null
chmod 0644 /usr/share/rpcd/acl.d/luci-app-podkop-tg.json 2>/dev/null
chmod 0644 /www/luci-static/resources/view/podkop-tg/settings.js 2>/dev/null
chmod 0644 /etc/podkop-telegram-agent/* 2>/dev/null
```

Потом обязательно прописать новый token и имя роутера:

```sh
uci set podkop_tg.main.token='TELEGRAM_BOT_TOKEN'
uci set podkop_tg.main.router_name='AX3000T'
uci set podkop_tg.main.podkop_section='main'
uci commit podkop_tg

/etc/init.d/podkop-telegram-agent enable
/etc/init.d/podkop-telegram-agent restart
```

## Сброс LuCI-кэша

```sh
rm -rf /tmp/luci-indexcache /tmp/luci-modulecache /tmp/luci-*cache
/etc/init.d/rpcd restart
/etc/init.d/uhttpd restart
```

## Логи

```sh
logread -e podkop-telegram-agent | tail -n 160
logread -e podkop | tail -n 80
logread -e sing-box | tail -n 80
logread | tail -n 160
```

## Безопасность

Не публикуй настоящий Telegram token. В репозитории держи `option token ''`, а token вводи только на роутере через UCI или LuCI.
