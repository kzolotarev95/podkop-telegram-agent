#!/bin/sh
# QUIET_HOURS_V132_HOTFIX_INSTALLER
# Applies Podkop Telegram Agent v1.0.32 quiet-hours hotfix over an installed v1.0.31/v1.0.30 agent.
# OpenWrt/BusyBox ash compatible.

set -u

YES=0
for arg in "$@"; do
    case "$arg" in
        --yes|-y) YES=1 ;;
        --help|-h)
            cat <<'HELP'
podkop-telegram-agent quiet-hours hotfix v1.0.32

Usage:
  ash install.sh --yes

What it changes:
  - adds quiet hours for automatic Telegram alerts;
  - default window: 23:00-08:00;
  - modes: queue/drop;
  - manual Telegram commands and daily report are not blocked.
HELP
            exit 0
            ;;
    esac
done

log() { printf '%s\n' "$*"; }
warn() { printf 'WARN: %s\n' "$*" >&2; }
fail() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }
have() { command -v "$1" >/dev/null 2>&1; }

AGENT="/usr/bin/podkop-telegram-agent"
LUCI="/www/luci-static/resources/view/podkop-tg/settings.js"
CONFIG="podkop_tg"
SECTION="main"
STAMP="$(date +%Y%m%d-%H%M%S 2>/dev/null || echo now)"

[ "$YES" = "1" ] || fail "run with --yes"
[ -f /etc/openwrt_release ] || warn "/etc/openwrt_release not found; continuing anyway"
have uci || fail "uci not found"
[ -f "$AGENT" ] || fail "$AGENT not found. Install podkop-telegram-agent v1.0.31 first."

insert_after_text() {
    local file="$1" pat="$2" token="$3" add="$4" tmp
    grep -qF "$token" "$file" 2>/dev/null && return 0
    tmp="${file}.tmp.$$"
    awk -v pat="$pat" -v add="$add" '
        { print; if (!done && index($0, pat) > 0) { print add; done=1 } }
        END { if (!done) exit 2 }
    ' "$file" > "$tmp" || { rm -f "$tmp"; return 1; }
    cat "$tmp" > "$file" && rm -f "$tmp"
}

insert_before_text() {
    local file="$1" pat="$2" token="$3" add="$4" tmp
    grep -qF "$token" "$file" 2>/dev/null && return 0
    tmp="${file}.tmp.$$"
    awk -v pat="$pat" -v add="$add" '
        { if (!done && index($0, pat) > 0) { print add; done=1 } print }
        END { if (!done) exit 2 }
    ' "$file" > "$tmp" || { rm -f "$tmp"; return 1; }
    cat "$tmp" > "$file" && rm -f "$tmp"
}

patch_agent() {
    log "Patching $AGENT ..."
    cp -a "$AGENT" "$AGENT.backup.quiet-v132.$STAMP" 2>/dev/null || true

    if ! grep -qF 'QUIET_HOURS_V132' "$AGENT"; then
        sed -i '/URLTEST_REAL_FIX_V131/a # QUIET_HOURS_V132: configurable night quiet hours for automatic alerts.' "$AGENT" 2>/dev/null || true
    fi
    sed -i 's/^BOT_VERSION=.*/BOT_VERSION="v1.0.9"/' "$AGENT" 2>/dev/null || true

    add_reads='    ALERT_QUIET_HOURS="$(uci -q get "$CONFIG.$SECTION.alert_quiet_hours")"
    ALERT_QUIET_START="$(uci -q get "$CONFIG.$SECTION.alert_quiet_start")"
    ALERT_QUIET_END="$(uci -q get "$CONFIG.$SECTION.alert_quiet_end")"
    ALERT_QUIET_MODE="$(uci -q get "$CONFIG.$SECTION.alert_quiet_mode")"'
    insert_after_text "$AGENT" 'ALERTS="$(uci -q get "$CONFIG.$SECTION.alerts")"' 'ALERT_QUIET_HOURS="$(uci -q get "$CONFIG.$SECTION.alert_quiet_hours")"' "$add_reads" || warn "could not add quiet-hour UCI reads"

    add_defaults='    [ -z "$ALERT_QUIET_HOURS" ] && ALERT_QUIET_HOURS=1
    [ -z "$ALERT_QUIET_START" ] && ALERT_QUIET_START="23:00"
    [ -z "$ALERT_QUIET_END" ] && ALERT_QUIET_END="08:00"
    [ -z "$ALERT_QUIET_MODE" ] && ALERT_QUIET_MODE="queue"
    case "$ALERT_QUIET_MODE" in queue|drop) ;; *) ALERT_QUIET_MODE="queue" ;; esac
    ALERT_QUIET_START="$(normalize_time_hhmm "$ALERT_QUIET_START")"
    ALERT_QUIET_END="$(normalize_time_hhmm "$ALERT_QUIET_END")"'
    insert_after_text "$AGENT" '[ -z "$ALERTS" ] && ALERTS=1' 'ALERT_QUIET_START="$(normalize_time_hhmm "$ALERT_QUIET_START")"' "$add_defaults" || warn "could not add quiet-hour defaults"

    funcs=$(cat <<'FUNCS'
normalize_time_hhmm() {
    local t="$1" h m
    [ -z "$t" ] && t="00:00"
    case "$t" in
        [0-9]:[0-5][0-9]) t="0$t" ;;
        [0-2][0-9]:[0-5][0-9]) ;;
        *) printf '00:00'; return ;;
    esac
    h="${t%:*}"
    m="${t#*:}"
    h="${h#0}"; [ -z "$h" ] && h=0
    m="${m#0}"; [ -z "$m" ] && m=0
    if [ "$h" -ge 0 ] 2>/dev/null && [ "$h" -le 23 ] 2>/dev/null && [ "$m" -ge 0 ] 2>/dev/null && [ "$m" -le 59 ] 2>/dev/null; then
        printf '%02d:%02d' "$h" "$m"
    else
        printf '00:00'
    fi
}

hhmm_to_minutes() {
    local t h m
    t="$(normalize_time_hhmm "$1")"
    h="${t%:*}"
    m="${t#*:}"
    h="${h#0}"; [ -z "$h" ] && h=0
    m="${m#0}"; [ -z "$m" ] && m=0
    echo $((h * 60 + m))
}

alert_quiet_active() {
    local now start end now_m start_m end_m
    [ "$ALERT_QUIET_HOURS" = "1" ] || return 1
    start="$(normalize_time_hhmm "${ALERT_QUIET_START:-23:00}")"
    end="$(normalize_time_hhmm "${ALERT_QUIET_END:-08:00}")"
    [ "$start" = "$end" ] && return 1
    now="$(date '+%H:%M')"
    now_m="$(hhmm_to_minutes "$now")"
    start_m="$(hhmm_to_minutes "$start")"
    end_m="$(hhmm_to_minutes "$end")"
    if [ "$start_m" -lt "$end_m" ] 2>/dev/null; then
        [ "$now_m" -ge "$start_m" ] 2>/dev/null && [ "$now_m" -lt "$end_m" ] 2>/dev/null
    else
        [ "$now_m" -ge "$start_m" ] 2>/dev/null || [ "$now_m" -lt "$end_m" ] 2>/dev/null
    fi
}

alert_quiet_summary() {
    local start end mode state
    start="$(normalize_time_hhmm "${ALERT_QUIET_START:-23:00}")"
    end="$(normalize_time_hhmm "${ALERT_QUIET_END:-08:00}")"
    mode="${ALERT_QUIET_MODE:-queue}"
    case "$mode" in drop) mode="не сохранять" ;; *) mode="отложить до утра" ;; esac
    if [ "$ALERT_QUIET_HOURS" = "1" ]; then
        if alert_quiet_active; then state="сейчас активно"; else state="сейчас не активно"; fi
        printf 'Тихие часы уведомлений: <code>%s-%s</code>, <code>%s</code>, <code>%s</code>' "$start" "$end" "$mode" "$state"
    else
        printf 'Тихие часы уведомлений: <code>выключены</code>'
    fi
}
FUNCS
)
    insert_before_text "$AGENT" 'router_header() {' 'normalize_time_hhmm()' "$funcs" || warn "could not add quiet-hour functions"

    insert_after_text "$AGENT" 'Время: <code>${now}</code>' '$(alert_quiet_summary)' '$(alert_quiet_summary)' || true

    help_add='
Ночные уведомления настраиваются в LuCI: тихие часы, начало, конец и режим — отложить до утра или не сохранять.
Текущее: $(alert_quiet_summary)'
    insert_after_text "$AGENT" '<code>/testreport ${router_html}</code> — тест ежедневного отчёта сейчас' 'Ночные уведомления настраиваются в LuCI' "$help_add" || true

    alert_add='    if alert_quiet_active; then
        if [ "$ALERT_QUIET_MODE" = "drop" ]; then
            log "alert suppressed by quiet hours kind=$kind title=$title window=${ALERT_QUIET_START}-${ALERT_QUIET_END} mode=drop"
            return 0
        fi
        queue_alert_event "$kind" "$title" "$message" "$logs_title" "$logs_body"
        log "alert postponed by quiet hours kind=$kind title=$title window=${ALERT_QUIET_START}-${ALERT_QUIET_END} mode=queue"
        return 1
    fi'
    insert_after_text "$AGENT" 'local kind="$1" title="$2" message="$3" logs_title="$4" logs_body="$5"' 'alert postponed by quiet hours' "$alert_add" || warn "could not patch send_alert_bundle"

    flush_add='    if alert_quiet_active; then
        log "alert queue flush postponed by quiet hours window=${ALERT_QUIET_START}-${ALERT_QUIET_END}"
        return
    fi'
    insert_after_text "$AGENT" '[ -n "$(get_admin_chats)" ] || return' 'alert queue flush postponed by quiet hours' "$flush_add" || warn "could not patch flush_alert_queue"

    chmod 0755 "$AGENT" 2>/dev/null || true
}

patch_luci() {
    [ -f "$LUCI" ] || { warn "$LUCI not found; LuCI patch skipped"; return 0; }
    log "Patching $LUCI ..."
    cp -a "$LUCI" "$LUCI.backup.quiet-v132.$STAMP" 2>/dev/null || true

    grep -qF 'QUIET_HOURS_V132' "$LUCI" || sed -i '/URLTEST_REAL_FIX_V131/a // QUIET_HOURS_V132: configurable night quiet hours for automatic alerts.' "$LUCI" 2>/dev/null || true
    sed -i "s/var BOT_VERSION = 'v1.0.8';/var BOT_VERSION = 'v1.0.9';/" "$LUCI" 2>/dev/null || true

    fields=$(cat <<'FIELDS'

        o = s.option(form.Flag, 'alert_quiet_hours', _('Тихие часы уведомлений'));
        o.default = '1';
        o.rmempty = false;
        o.description = _('Не отправлять автоматические уведомления ночью. Ручные команды Telegram и ежедневный отчёт не блокируются.');

        o = s.option(form.Value, 'alert_quiet_start', _('Начало тихих часов'));
        o.depends('alert_quiet_hours', '1');
        o.placeholder = '23:00';
        o.default = '23:00';
        o.rmempty = false;
        o.description = _('Формат HH:MM. Например 23:00.');
        o.validate = function(section_id, value) {
            if (!/^([01]?\d|2[0-3]):[0-5]\d$/.test(value || ''))
                return _('Укажите время в формате HH:MM, например 23:00.');
            return true;
        };

        o = s.option(form.Value, 'alert_quiet_end', _('Конец тихих часов'));
        o.depends('alert_quiet_hours', '1');
        o.placeholder = '08:00';
        o.default = '08:00';
        o.rmempty = false;
        o.description = _('Формат HH:MM. Например 08:00. Если начало больше конца, интервал считается через полночь.');
        o.validate = function(section_id, value) {
            if (!/^([01]?\d|2[0-3]):[0-5]\d$/.test(value || ''))
                return _('Укажите время в формате HH:MM, например 08:00.');
            return true;
        };

        o = s.option(form.ListValue, 'alert_quiet_mode', _('Что делать с ночными уведомлениями'));
        o.depends('alert_quiet_hours', '1');
        o.value('queue', _('Отложить и отправить после тихих часов'));
        o.value('drop', _('Не сохранять и не отправлять'));
        o.default = 'queue';
        o.rmempty = false;
        o.description = _('В режиме «отложить» бот не шумит ночью, но утром отправит накопленные уведомления и логи. В режиме «не сохранять» ночные авто-уведомления будут просто пропущены.');
FIELDS
)
    insert_before_text "$LUCI" "o = s.option(form.Flag, 'daily_report'" "alert_quiet_mode" "$fields" || warn "could not add LuCI quiet-hour fields"
    chmod 0644 "$LUCI" 2>/dev/null || true
}

patch_config() {
    log "Updating UCI defaults ..."
    uci -q get "$CONFIG.$SECTION" >/dev/null 2>&1 || uci set "$CONFIG.$SECTION=bot"
    uci -q get "$CONFIG.$SECTION.alert_quiet_hours" >/dev/null 2>&1 || uci set "$CONFIG.$SECTION.alert_quiet_hours=1"
    uci -q get "$CONFIG.$SECTION.alert_quiet_start" >/dev/null 2>&1 || uci set "$CONFIG.$SECTION.alert_quiet_start=23:00"
    uci -q get "$CONFIG.$SECTION.alert_quiet_end" >/dev/null 2>&1 || uci set "$CONFIG.$SECTION.alert_quiet_end=08:00"
    uci -q get "$CONFIG.$SECTION.alert_quiet_mode" >/dev/null 2>&1 || uci set "$CONFIG.$SECTION.alert_quiet_mode=queue"
    uci commit "$CONFIG" || true
}

patch_config
patch_agent
patch_luci

log "Clearing LuCI cache and restarting services ..."
rm -rf /tmp/luci-indexcache /tmp/luci-modulecache /tmp/luci-*cache 2>/dev/null || true
/etc/init.d/podkop-telegram-agent restart 2>/dev/null || true
/etc/init.d/rpcd restart 2>/dev/null || true
/etc/init.d/uhttpd restart 2>/dev/null || true

log ""
log "Installed quiet-hours hotfix v1.0.32."
log "Check:"
log "  grep -n \"QUIET_HOURS_V132\" /usr/bin/podkop-telegram-agent /www/luci-static/resources/view/podkop-tg/settings.js"
log "  uci show podkop_tg | sed \"s/token='[^']*'/token='***'/\""
log "  logread | grep -Ei 'podkop-telegram-agent|podkop_tg|podkop|sing-box|rpcd|uhttpd' | tail -n 250"
