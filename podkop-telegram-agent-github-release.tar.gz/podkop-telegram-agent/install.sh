#!/bin/sh
# HELP_TEXT_FORCE_V134_HOTFIX_INSTALLER
# OpenWrt/BusyBox ash compatible.
# Forces Telegram ❓ Help button and /help to send text command list, not header-only image.

set -u

YES=0
for arg in "$@"; do
    case "$arg" in
        --yes|-y) YES=1 ;;
        --help|-h)
            cat <<'HELP'
podkop-telegram-agent help text force hotfix v1.0.34

Usage:
  ash install.sh --yes

What it changes:
  - forces ❓ Помощь / Помощь / /help to send command list as text;
  - blocks menu header image for help only;
  - writes Telegram API response to /tmp/podkop_tg_help_v134.log;
  - keeps visible bot version: Podkop Telegram Agent v1.0.9.
HELP
            exit 0
            ;;
    esac
done

log() { printf '%s\n' "$*"; }
warn() { printf 'WARN: %s\n' "$*" >&2; }
fail() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }
have() { command -v "$1" >/dev/null 2>&1; }

AGENT="/usr/bin/podkop-telegram-agent"
LUCI="/www/luci-static/resources/view/podkop-tg/settings.js"
MARKER="HELP_TEXT_FORCE_V134"
STAMP="$(date +%Y%m%d-%H%M%S 2>/dev/null || echo now)"

[ "$YES" = "1" ] || fail "run with --yes"
[ -f /etc/openwrt_release ] || warn "/etc/openwrt_release not found; continuing anyway"
[ -f "$AGENT" ] || fail "$AGENT not found. Install podkop-telegram-agent first."

insert_before_func() {
    local file="$1" func="$2" token="$3" add="$4" tmp
    grep -qF "$token" "$file" 2>/dev/null && return 0
    tmp="${file}.tmp.$$"
    awk -v func="$func" -v add="$add" '
        { if (!done && index($0, func) > 0) { print add; done=1 } print }
        END { if (!done) exit 2 }
    ' "$file" > "$tmp" || { rm -f "$tmp"; return 1; }
    cat "$tmp" > "$file" && rm -f "$tmp"
}

patch_help_case() {
    local file="$1" tmp
    grep -qF 'send_help_commands_v134 "$chat"' "$file" 2>/dev/null && return 0
    tmp="${file}.tmp.$$"
    awk '
        function body_no_end() {
            print "            send_help_commands_v134 \"$chat\""
            print "            return"
            print "            # HELP_TEXT_FORCE_V134_HELP_CASE"
        }
        function body_with_end() {
            print "        /help)"
            print "            send_help_commands_v134 \"$chat\""
            print "            return"
            print "            ;; # HELP_TEXT_FORCE_V134_HELP_CASE"
        }
        {
            if (!done && $0 ~ /^[[:space:]]*\/help\)/) {
                print
                body_no_end()
                done=1
                next
            }
            if (!done && (index($0, "/start|/help)") > 0 || index($0, "/help|/start)") > 0)) {
                body_with_end()
                print
                done=1
                next
            }
            print
        }
        END { if (!done) exit 2 }
    ' "$file" > "$tmp" || { rm -f "$tmp"; return 1; }
    cat "$tmp" > "$file" && rm -f "$tmp"
}

patch_text_to_command_map() {
    local file="$1" tmp
    grep -qF 'HELP_TEXT_FORCE_V134_MENU_MAP' "$file" 2>/dev/null && return 0
    tmp="${file}.tmp.$$"
    awk '
        /^[[:space:]]*text_to_command\(\)/ { in_text=1 }
        in_text && !done && /^[[:space:]]*case[[:space:]]/ {
            print
            print "        *\"Помощь\"*|*\"HELP\"*|*\"Help\"*|/help*) echo \"/help\"; return ;; # HELP_TEXT_FORCE_V134_MENU_MAP"
            done=1
            next
        }
        in_text && /^[[:space:]]*}\s*$/ { in_text=0 }
        { print }
        END { if (!done) exit 2 }
    ' "$file" > "$tmp" || { rm -f "$tmp"; return 1; }
    cat "$tmp" > "$file" && rm -f "$tmp"
}

patch_normalize_button_map() {
    local file="$1" tmp
    grep -qF 'HELP_TEXT_FORCE_V134_NORMALIZE_MAP' "$file" 2>/dev/null && return 0
    tmp="${file}.tmp.$$"
    awk '
        /^[[:space:]]*normalize_button\(\)/ { in_norm=1 }
        in_norm && !done && /^[[:space:]]*case[[:space:]]/ {
            print
            print "        *\"Помощь\"*) echo \"/help\"; return ;; # HELP_TEXT_FORCE_V134_NORMALIZE_MAP"
            done=1
            next
        }
        in_norm && /^[[:space:]]*}\s*$/ { in_norm=0 }
        { print }
        END { if (!done) exit 2 }
    ' "$file" > "$tmp" || { rm -f "$tmp"; return 1; }
    cat "$tmp" > "$file" && rm -f "$tmp"
}

patch_no_help_header() {
    local file="$1" func="$2" token="$3" line="$4" tmp
    grep -qF "$token" "$file" 2>/dev/null && return 0
    tmp="${file}.tmp.$$"
    awk -v func="$func" -v line="$line" '
        { print; if (!done && index($0, func) > 0) { print line; done=1 } }
        END { if (!done) exit 2 }
    ' "$file" > "$tmp" || { rm -f "$tmp"; return 1; }
    cat "$tmp" > "$file" && rm -f "$tmp"
}

patch_agent() {
    local backup funcs
    log "Patching $AGENT ..."
    backup="$AGENT.backup.help-v134.$STAMP"
    cp -a "$AGENT" "$backup" 2>/dev/null || true

    if ! grep -qF "$MARKER" "$AGENT" 2>/dev/null; then
        sed -i '/HELP_BUTTON_TEXT_FIX_V133/a # HELP_TEXT_FORCE_V134: force /help and ❓ Помощь to send text command list; suppress header for help.' "$AGENT" 2>/dev/null || \
        sed -i '/QUIET_HOURS_V132/a # HELP_TEXT_FORCE_V134: force /help and ❓ Помощь to send text command list; suppress header for help.' "$AGENT" 2>/dev/null || \
        sed -i '/URLTEST_REAL_FIX_V131/a # HELP_TEXT_FORCE_V134: force /help and ❓ Помощь to send text command list; suppress header for help.' "$AGENT" 2>/dev/null || \
        sed -i '1a # HELP_TEXT_FORCE_V134: force /help and ❓ Помощь to send text command list; suppress header for help.' "$AGENT" 2>/dev/null || true
    fi

    # Keep the visible Telegram/LuCI version requested earlier.
    sed -i 's/^BOT_VERSION=.*/BOT_VERSION="v1.0.9"/' "$AGENT" 2>/dev/null || true

    funcs=$(cat <<'FUNCS'
help_commands_text_v134() {
    local router_html sec_html quiet_line
    if command -v escape_html >/dev/null 2>&1; then
        router_html="$(printf '%s' "${ROUTER_NAME:-openwrt}" | escape_html)"
        sec_html="$(printf '%s' "${PODKOP_SECTION:-main}" | escape_html)"
    else
        router_html="${ROUTER_NAME:-openwrt}"
        sec_html="${PODKOP_SECTION:-main}"
    fi
    quiet_line=""
    if command -v alert_quiet_summary >/dev/null 2>&1; then
        quiet_line="$(alert_quiet_summary 2>/dev/null || true)"
    fi
    cat <<EOF_HELP_V134
<b>Podkop Telegram Agent ${BOT_VERSION}</b>
Роутер: <code>${router_html}</code>

<b>Основные команды:</b>
<code>/start</code> — картинка и меню
<code>/help</code> — этот список команд
<code>/status ${router_html}</code> — статус
<code>/report ${router_html}</code> — полный отчёт
<code>/logs ${router_html} all 200</code> — логи
<code>/diag ${router_html}</code> — диагностика
<code>/health ${router_html}</code> — Tunnel Health
<code>/probe ${router_html}</code> — Active Outbound Probe
<code>/restart ${router_html}</code> — меню перезагрузки
<code>/backup ${router_html}</code> — backup OpenWrt
<code>/bundle ${router_html}</code> — support bundle
<code>/myid</code> — мой Telegram ID

<b>Podkop / URLTest:</b>
<code>/urltest ${router_html}</code> — список ссылок
<code>/urlping ${router_html}</code> — проверить серверы
<code>/urlteston ${router_html} ${sec_html}</code> — включить URLTest
<code>/urluse ${router_html} 1</code> — выбрать ссылку №1
<code>/urladd ${router_html} ${sec_html} vless://...</code> — добавить ссылку
<code>/urldel ${router_html} 1</code> — удалить ссылку
<code>/urlapply ${router_html}</code> — применить/restart Podkop
<code>/update ${router_html} vless://... ${sec_html}</code> — заменить proxy URL
<code>/section ${router_html} ${sec_html}</code> — выбрать секцию
<code>/sections ${router_html}</code> — список секций

<b>Доступ устройств:</b>
<code>/access ${router_html}</code> — правила
<code>/accesshelp ${router_html}</code> — примеры
<code>/accessadd ${router_html} tv 192.168.1.50 14:00-20:00 mon-fri</code>
<code>/accessblock ${router_html} tv</code> — блокировать
<code>/accessunblock ${router_html} tv</code> — снять блок
<code>/accessdel ${router_html} tv</code> — удалить

<b>Сервис:</b>
<code>/testreport ${router_html}</code> — тест отчёта
<code>/header ${router_html}</code> — проверить картинку
<code>/botupdate ${router_html}</code> — обновить бота
<code>/podkopupdate ${router_html}</code> — обновить Podkop
<code>/donate ${router_html}</code> — донат
${quiet_line}
EOF_HELP_V134
}

send_help_commands_v134() {
    local chat="$1" text resp rc client
    [ -n "${TOKEN:-}" ] || return 1
    [ -n "$chat" ] || return 1
    text="$(help_commands_text_v134)"
    printf '%s\n' "$text" >/tmp/podkop_tg_help_v134_text.txt
    if command -v tg_curl >/dev/null 2>&1; then
        client="tg_curl"
    else
        client="curl"
    fi
    resp="$($client -sS --max-time 25 -X POST "$API/sendMessage" \
        --data-urlencode "chat_id=$chat" \
        --data-urlencode "text=$text" \
        --data-urlencode "parse_mode=HTML" \
        --data-urlencode "disable_web_page_preview=true" \
        --data-urlencode "reply_markup=$(keyboard_json)" 2>&1)"
    rc=$?
    printf 'rc=%s\n%s\n' "$rc" "$resp" >/tmp/podkop_tg_help_v134.log
    if [ "$rc" -ne 0 ]; then
        log "HELP_TEXT_FORCE_V134 send failed rc=$rc response=$(printf '%s' "$resp" | head -c 180)"
        return 1
    fi
    printf '%s' "$resp" | grep -q '"ok"[[:space:]]*:[[:space:]]*true' && {
        log "HELP_TEXT_FORCE_V134 help text sent"
        return 0
    }
    if command -v jq >/dev/null 2>&1; then
        printf '%s' "$resp" | jq -e '.ok == true' >/dev/null 2>&1 && {
            log "HELP_TEXT_FORCE_V134 help text sent"
            return 0
        }
    fi
    log "HELP_TEXT_FORCE_V134 send unexpected response=$(printf '%s' "$resp" | head -c 180)"
    return 1
}
FUNCS
)

    insert_before_func "$AGENT" 'text_to_command()' 'help_commands_text_v134()' "$funcs" || \
    insert_before_func "$AGENT" 'normalize_button()' 'help_commands_text_v134()' "$funcs" || \
    insert_before_func "$AGENT" 'handle_command()' 'help_commands_text_v134()' "$funcs" || \
    fail "could not insert v1.0.34 help functions"

    patch_help_case "$AGENT" || fail "could not patch /help handler"
    patch_text_to_command_map "$AGENT" || warn "could not patch text_to_command map; direct /help is still fixed"
    patch_normalize_button_map "$AGENT" || warn "could not patch normalize_button map; text_to_command/direct /help is still fixed"

    patch_no_help_header "$AGENT" 'maybe_send_button_header()' 'HELP_TEXT_FORCE_V134_NO_HELP_HEADER' '    case "${2:-}" in *"Помощь"*|*"помощь"*|/help*) return 0 ;; esac # HELP_TEXT_FORCE_V134_NO_HELP_HEADER' || warn "could not patch maybe_send_button_header"
    patch_no_help_header "$AGENT" 'is_header_menu_button()' 'HELP_TEXT_FORCE_V134_NO_HELP_HEADER_CHECK' '    case "${1:-}" in *"Помощь"*|*"помощь"*|/help*) return 1 ;; esac # HELP_TEXT_FORCE_V134_NO_HELP_HEADER_CHECK' || warn "could not patch is_header_menu_button"

    chmod 0755 "$AGENT" 2>/dev/null || true
    if have ash; then
        if ! ash -n "$AGENT" >/tmp/podkop_tg_help_v134_syntax.log 2>&1; then
            warn "syntax check failed, restoring backup $backup"
            cp -a "$backup" "$AGENT" 2>/dev/null || true
            cat /tmp/podkop_tg_help_v134_syntax.log >&2 2>/dev/null || true
            fail "agent syntax check failed"
        fi
    fi
}

patch_luci() {
    [ -f "$LUCI" ] || return 0
    log "Marking $LUCI ..."
    cp -a "$LUCI" "$LUCI.backup.help-v134.$STAMP" 2>/dev/null || true
    if ! grep -qF "$MARKER" "$LUCI" 2>/dev/null; then
        sed -i '/HELP_BUTTON_TEXT_FIX_V133/a // HELP_TEXT_FORCE_V134: Help button and /help send text list, not header-only image.' "$LUCI" 2>/dev/null || \
        sed -i '/QUIET_HOURS_V132/a // HELP_TEXT_FORCE_V134: Help button and /help send text list, not header-only image.' "$LUCI" 2>/dev/null || \
        sed -i '1a // HELP_TEXT_FORCE_V134: Help button and /help send text list, not header-only image.' "$LUCI" 2>/dev/null || true
    fi
    sed -i "s/var BOT_VERSION = 'v1.0.8';/var BOT_VERSION = 'v1.0.9';/" "$LUCI" 2>/dev/null || true
    chmod 0644 "$LUCI" 2>/dev/null || true
}

patch_agent
patch_luci

log "Clearing LuCI cache and restarting services ..."
rm -rf /tmp/luci-indexcache /tmp/luci-modulecache /tmp/luci-*cache 2>/dev/null || true
/etc/init.d/podkop-telegram-agent restart 2>/dev/null || true
/etc/init.d/rpcd restart 2>/dev/null || true
/etc/init.d/uhttpd restart 2>/dev/null || true

log ""
log "Installed help text force hotfix v1.0.34."
log "Check:"
log "  grep -n \"HELP_TEXT_FORCE_V134\" /usr/bin/podkop-telegram-agent /www/luci-static/resources/view/podkop-tg/settings.js"
log "  /etc/init.d/podkop-telegram-agent status"
log "  cat /tmp/podkop_tg_help_v134.log"
log "  logread | grep -Ei 'podkop-telegram-agent|podkop_tg|rpcd|uhttpd' | tail -n 250"
log "  logread -f"
