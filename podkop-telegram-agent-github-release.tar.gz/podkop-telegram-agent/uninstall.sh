#!/bin/sh
set -e

/etc/init.d/podkop-telegram-agent stop 2>/dev/null || true
/etc/init.d/podkop-telegram-agent disable 2>/dev/null || true

# Clear device access firewall rules created by bot.
if command -v nft >/dev/null 2>&1; then
    nft delete table inet podkop_tg_access >/dev/null 2>&1 || true
fi
if command -v iptables >/dev/null 2>&1; then
    iptables -D FORWARD -j PODKOP_TG_ACCESS >/dev/null 2>&1 || true
    iptables -F PODKOP_TG_ACCESS >/dev/null 2>&1 || true
    iptables -X PODKOP_TG_ACCESS >/dev/null 2>&1 || true
fi

rm -f /usr/bin/podkop-telegram-agent
rm -f /etc/init.d/podkop-telegram-agent
rm -f /usr/share/luci/menu.d/luci-app-podkop-tg.json
rm -f /usr/share/rpcd/acl.d/luci-app-podkop-tg.json
rm -rf /www/luci-static/resources/view/podkop-tg
rm -f /tmp/podkop_tg_offset /tmp/podkop_tg_last_state /tmp/podkop_tg_last_alert /tmp/podkop_tg_last_report /tmp/podkop_tg_update.lock /tmp/podkop_tg_last_update /tmp/podkop_tg_access_last

if [ -x /etc/init.d/rpcd ]; then
    /etc/init.d/rpcd restart >/dev/null 2>&1 || true
fi
if [ -x /etc/init.d/uhttpd ]; then
    /etc/init.d/uhttpd reload >/dev/null 2>&1 || /etc/init.d/uhttpd restart >/dev/null 2>&1 || true
fi
rm -rf /tmp/luci-indexcache /tmp/luci-modulecache 2>/dev/null || true

echo "Uninstalled. Config /etc/config/podkop_tg and /etc/podkop-telegram-agent were kept. Remove them manually if needed."
