#!/bin/sh
# Helper for clean OpenWrt install.
# Run from unpacked podkop-telegram-agent directory:
#   ash scripts/install-clean-openwrt.sh

set -u

echo "[1/4] Installing packages..."
opkg update
opkg install curl jq ca-bundle unzip tar gzip rpcd-mod-file iwinfo || {
    echo "WARN: some packages failed. Minimum required: curl jq ca-bundle"
}

echo "[2/4] Running installer..."
ash install.sh --yes

echo "[3/4] Restarting LuCI..."
rm -rf /tmp/luci-indexcache /tmp/luci-modulecache /tmp/luci-*cache
/etc/init.d/rpcd restart 2>/dev/null || true
/etc/init.d/uhttpd restart 2>/dev/null || true

echo "[4/4] Status/logs..."
/etc/init.d/podkop-telegram-agent status || true
logread -e podkop-telegram-agent | tail -n 80
