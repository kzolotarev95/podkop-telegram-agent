#!/bin/sh
# Create full podkop-telegram-agent backup without Telegram token.
# OpenWrt / BusyBox ash compatible.

set -u

TMP="/tmp/podkop-tg-backup-no-token"
ROUTER="$(uci -q get podkop_tg.main.router_name 2>/dev/null || hostname 2>/dev/null || echo openwrt)"
DATE="$(date +%Y%m%d-%H%M%S 2>/dev/null || echo now)"
BACKUP="/tmp/podkop-telegram-agent-backup-no-token-${ROUTER}-${DATE}.tar.gz"
ERR="/tmp/podkop_tg_backup_errors.log"

rm -rf "$TMP"
mkdir -p "$TMP/usr/bin" \
         "$TMP/etc/init.d" \
         "$TMP/etc/config" \
         "$TMP/etc/podkop-telegram-agent" \
         "$TMP/usr/share/luci/menu.d" \
         "$TMP/usr/share/rpcd/acl.d" \
         "$TMP/www/luci-static/resources/view/podkop-tg"

: > "$ERR"

cp -a /usr/bin/podkop-telegram-agent "$TMP/usr/bin/" 2>>"$ERR" || true
cp -a /usr/bin/podkop-telegram-agent-logread "$TMP/usr/bin/" 2>>"$ERR" || true
cp -a /etc/init.d/podkop-telegram-agent "$TMP/etc/init.d/" 2>>"$ERR" || true
cp -a /etc/config/podkop_tg "$TMP/etc/config/" 2>>"$ERR" || true
cp -a /etc/podkop-telegram-agent/. "$TMP/etc/podkop-telegram-agent/" 2>>"$ERR" || true
cp -a /usr/share/luci/menu.d/luci-app-podkop-tg.json "$TMP/usr/share/luci/menu.d/" 2>>"$ERR" || true
cp -a /usr/share/rpcd/acl.d/luci-app-podkop-tg.json "$TMP/usr/share/rpcd/acl.d/" 2>>"$ERR" || true
cp -a /www/luci-static/resources/view/podkop-tg/settings.js "$TMP/www/luci-static/resources/view/podkop-tg/" 2>>"$ERR" || true

if [ -f "$TMP/etc/config/podkop_tg" ]; then
    sed -i "/^[[:space:]]*option[[:space:]]\+token[[:space:]]/c\\	option token ''" "$TMP/etc/config/podkop_tg"
fi

tar -czpf "$BACKUP" -C "$TMP" .
sha256sum "$BACKUP" > "$BACKUP.sha256" 2>/dev/null || true

echo "Created:"
ls -lh "$BACKUP" "$BACKUP.sha256" 2>/dev/null || ls -lh "$BACKUP"

echo ""
echo "Token check:"
tar -xOzf "$BACKUP" ./etc/config/podkop_tg 2>/dev/null | grep "token" || true

echo ""
echo "Warnings/errors, if any:"
cat "$ERR" 2>/dev/null || true

echo ""
echo "Download from PC:"
echo "scp root@ROUTER_IP:$BACKUP ."
echo "scp root@ROUTER_IP:$BACKUP.sha256 ."
