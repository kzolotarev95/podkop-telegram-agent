'use strict';

// LUCISTRIPANSI_V127: fixed LuCI strict-mode octal/control char error in stripAnsi().
// ROUTER_NAME_HARDFIX_V129: preserve router names and repair uppercase-to-underscore corruption.
// QUIET_STATUS_V11010: LuCI fields and active/inactive status for alert quiet hours.
// HELP_BUTTON_OUTPUT_V11011: Help button sends text list, not only header image.
// SPEED_TC_QOS_V11014: speed limiter uses tc/HTB/fq_codel + IFB instead of nft limit.
// OpenWrt 25 LuCI may fail with 'view.extend is not a function' if variables are placed before requires.
'require view';
'require form';
'require uci';
'require fs';
'require ui';
'require poll';

var BOT_VERSION = 'v1.10.14';

function serviceStatus() {
    return fs.exec('/etc/init.d/podkop-telegram-agent', [ 'status' ]).then(function(res) {
        return res.code === 0;
    }).catch(function() {
        return false;
    });
}

function serviceAction(action) {
    return fs.exec('/etc/init.d/podkop-telegram-agent', [ action ]).then(function(res) {
        if (res.code !== 0)
            throw new Error(res.stderr || res.stdout || _('Ошибка выполнения команды'));
        ui.addNotification(null, E('p', _('Команда выполнена: ') + action));
    }).catch(function(err) {
        ui.addNotification(null, E('p', _('Ошибка выполнения: ') + (err.message || err)), 'danger');
    });
}


function stripAnsi(text) {
    return (text || '').replace(new RegExp('\\x1b\\[[0-?]*[ -/]*[@-~]', 'g'), '');
}

function copyLogsToClipboard(textarea, text) {
    var done = function() {
        ui.addNotification(null, E('p', _('Логи скопированы в буфер обмена')));
    };

    if (navigator.clipboard && navigator.clipboard.writeText) {
        return navigator.clipboard.writeText(text).then(done).catch(function() {
            textarea.focus();
            textarea.select();
            document.execCommand('copy');
            done();
        });
    }

    textarea.focus();
    textarea.select();
    document.execCommand('copy');
    done();
}

function showLogsModal(lines, text) {
    var textarea = E('textarea', {
        'readonly': 'readonly',
        'wrap': 'off',
        'style': 'width: 100%; min-height: 55vh; max-height: 65vh; overflow: auto; box-sizing: border-box; font-family: monospace; white-space: pre; padding: 1em; border: 1px solid #ccc; border-radius: 6px; resize: vertical;'
    }, text || _('Логи пустые'));

    ui.showModal(_('📄 Посмотреть логи'), [
        E('p', {}, _('Показан полный logread без фильтра, последние %s строк.').format(lines)),
        textarea,
        E('div', { 'class': 'right', 'style': 'margin-top: 1em;' }, [
            E('button', {
                'class': 'btn cbi-button cbi-button-action',
                'click': function(ev) {
                    ev.preventDefault();
                    return copyLogsToClipboard(textarea, text || '');
                }
            }, _('Копировать')),
            ' ',
            E('button', {
                'class': 'btn cbi-button cbi-button-reset',
                'click': function(ev) {
                    ev.preventDefault();
                    ui.hideModal();
                }
            }, _('Закрыть'))
        ])
    ]);
}

function showAllLogs() {
    return uci.load('podkop_tg').then(function() {
        var lines = parseInt(uci.get('podkop_tg', 'main', 'log_lines') || '200', 10);
        if (!isFinite(lines) || lines < 200)
            lines = 200;
        if (lines > 1000)
            lines = 1000;

        ui.showModal(_('📄 Посмотреть логи'), [
            E('p', {}, _('Загружаю полный logread, последние %s строк…').format(lines)),
            E('div', { 'class': 'spinning' }, _('Пожалуйста, подождите')),
            E('div', { 'class': 'right', 'style': 'margin-top: 1em;' }, [
                E('button', {
                    'class': 'btn cbi-button cbi-button-reset',
                    'click': function(ev) {
                        ev.preventDefault();
                        ui.hideModal();
                    }
                }, _('Закрыть'))
            ])
        ]);

        return fs.exec('/usr/bin/podkop-telegram-agent-logread', [ String(lines) ]).then(function(res) {
            var text = stripAnsi(res.stdout || res.stderr || _('Логи пустые'));
            showLogsModal(lines, text);
        }).catch(function(err) {
            ui.showModal(_('📄 Посмотреть логи'), [
                E('p', {}, _('Не удалось прочитать логи: ') + (err.message || err)),
                E('div', { 'class': 'right', 'style': 'margin-top: 1em;' }, [
                    E('button', {
                        'class': 'btn cbi-button cbi-button-reset',
                        'click': function(ev) {
                            ev.preventDefault();
                            ui.hideModal();
                        }
                    }, _('Закрыть'))
                ])
            ]);
        });
    });
}

function normalizeRouterName(name) {
    // ROUTER_NAME_HARDFIX_V129:
    // Preserve router names for Telegram buttons. Do not convert uppercase
    // letters to underscores. Only trim spaces and replace unsafe chars.
    // NanoPiR3S -> NanoPiR3S, RAX1 -> RAX1, WBR3000UAX -> WBR3000UAX.
    var raw = String(name || '').trim();
    var out = '';

    for (var i = 0; i < raw.length; i++) {
        var c = raw.charAt(i);
        var code = raw.charCodeAt(i);

        if ((code >= 65 && code <= 90) ||
            (code >= 97 && code <= 122) ||
            (code >= 48 && code <= 57) ||
            c === '_' || c === '-' || c === '.' || c === '@' || c === '#' || c === ':') {
            out += c;
            continue;
        }

        out += '_';
    }

    out = out.replace(/_+/g, '_').replace(/^_+|_+$/g, '');
    return out || 'openwrt';
}

function routerNameKey(name) {
    return normalizeRouterName(name).toLowerCase();
}

function stripBySuffix(name) {
    return String(name || '').replace(/_[bB][yY].*$/, '');
}

function firstNonEmptyLine(text) {
    var lines = String(text || '').split(/\r?\n/);
    for (var i = 0; i < lines.length; i++) {
        var line = lines[i].trim();
        if (line)
            return line;
    }
    return '';
}

function systemHostname() {
    return fs.exec('/bin/sh', [ '-c', "cat /proc/sys/kernel/hostname 2>/dev/null; hostname 2>/dev/null" ]).then(function(res) {
        return normalizeRouterName(stripBySuffix(firstNonEmptyLine(res.stdout) || 'openwrt'));
    }).catch(function() {
        return 'openwrt';
    });
}

function countChar(text, ch) {
    text = String(text || '');
    var n = 0;
    for (var i = 0; i < text.length; i++)
        if (text.charAt(i) === ch)
            n++;
    return n;
}

function looksLikeUppercaseUnderscoreBug(name, hostname) {
    var n = normalizeRouterName(name);
    var h = normalizeRouterName(hostname);
    if (!n || !h || h === 'openwrt' || routerNameKey(n) === routerNameKey(h))
        return false;
    if (n.indexOf('_') < 0)
        return false;
    return countChar(n, '_') > countChar(h, '_') || (countChar(h, '_') === 0 && countChar(n, '_') > 0);
}

function badRouterName(name, hostname) {
    name = String(name || '');
    if (!name || /^(openwrt|o__nwrt|o--nwrt|o_nwrt|ow_nwrt|localhost|router|n_no_i|n_no_ir3s|ano_i_3|r_x|r_x1|wbr3000u_x|wbr3000u_x_byzk_95|wvr3000u_x|wvr3000u_x_byzk_95|3000|1)$/i.test(name))
        return true;
    return looksLikeUppercaseUnderscoreBug(name, hostname);
}

function routerNameValue(section_id, hostname) {
    var cur = uci.get('podkop_tg', section_id, 'router_name');
    return badRouterName(cur, hostname) ? hostname : normalizeRouterName(cur);
}

function normalizeRouterList(value) {
    var parts = String(value || '').split(/[\s,;]+/);
    var seen = {}, out = [];
    for (var i = 0; i < parts.length; i++) {
        var n = normalizeRouterName(parts[i]);
        if (!n || badRouterName(n, ''))
            continue;
        var key = routerNameKey(n);
        if (!seen[key]) {
            out.push(n);
            seen[key] = true;
        }
    }
    return out.join(' ');
}


function normalizeHHMM(value, fallback) {
    value = String(value || fallback || '00:00').trim();
    var m = value.match(/^(\d{1,2}):([0-5]\d)$/);
    if (!m)
        value = String(fallback || '00:00');
    m = value.match(/^(\d{1,2}):([0-5]\d)$/);
    if (!m)
        return '00:00';
    var h = parseInt(m[1], 10);
    var min = parseInt(m[2], 10);
    if (!isFinite(h) || h < 0 || h > 23)
        h = 0;
    return (h < 10 ? '0' : '') + h + ':' + (min < 10 ? '0' : '') + min;
}

function hhmmToMinutes(value) {
    value = normalizeHHMM(value, '00:00');
    var p = value.split(':');
    return parseInt(p[0], 10) * 60 + parseInt(p[1], 10);
}

function quietActiveNow(start, end) {
    start = normalizeHHMM(start, '23:00');
    end = normalizeHHMM(end, '08:00');
    if (start === end)
        return false;
    var now = new Date();
    var nowMin = now.getHours() * 60 + now.getMinutes();
    var startMin = hhmmToMinutes(start);
    var endMin = hhmmToMinutes(end);
    if (startMin < endMin)
        return nowMin >= startMin && nowMin < endMin;
    return nowMin >= startMin || nowMin < endMin;
}

function quietModeHuman(mode) {
    return mode === 'drop' ? _('подавлять') : _('отложить до утра');
}

function quietStatusText(section_id) {
    var enabled = uci.get('podkop_tg', section_id, 'alert_quiet_hours');
    var start = normalizeHHMM(uci.get('podkop_tg', section_id, 'alert_quiet_start'), '23:00');
    var end = normalizeHHMM(uci.get('podkop_tg', section_id, 'alert_quiet_end'), '08:00');
    var mode = uci.get('podkop_tg', section_id, 'alert_quiet_mode') || 'queue';
    if (enabled === '0')
        return _('выключены, сейчас не активно');
    return start + '-' + end + ', ' + quietModeHuman(mode) + ', ' + (quietActiveNow(start, end) ? _('сейчас активно') : _('сейчас не активно'));
}

return view.extend({
    load: function() {
        return Promise.all([
            uci.load('podkop_tg'),
            serviceStatus(),
            systemHostname()
        ]);
    },

    render: function(data) {
        var running = data[1];
        var hostname = data[2] || 'openwrt';
        var m, s, o;

        m = new form.Map('podkop_tg', _('Podkop Telegram'), E('span', {}, [
            _('Спасибо большое за данный модуль начинающему скриптеру '),
            E('a', {
                'href': 'https://t.me/kzolotarev95',
                'target': '_blank',
                'rel': 'noopener noreferrer',
                'style': 'color: #e74c3c; font-weight: 700;'
            }, 'by zks95'),
            E('br'),
            E('small', { 'style': 'opacity:.72; font-size:11px;' }, _('Версия: Podkop Telegram Agent ') + BOT_VERSION),
            E('br'),
            E('small', { 'style': 'opacity:.72; font-size:11px;' }, [
                E('a', { 'href': 'https://github.com/kzolotarev95/podkop-telegram-agent', 'target': '_blank', 'rel': 'noopener noreferrer' }, 'GitHub'),
                ' · ',
                E('a', { 'href': 'https://t.me/kzolotarev95', 'target': '_blank', 'rel': 'noopener noreferrer' }, 'Telegram')
            ])
        ]));

        s = m.section(form.NamedSection, 'main', 'bot', _('Настройки бота'));
        s.addremove = false;
        s.anonymous = true;

        o = s.option(form.DummyValue, '_state', _('Статус агента'));
        o.rawhtml = true;
        o.cfgvalue = function() {
            return running
                ? '<strong style="color:green">ЗАПУЩЕН</strong>'
                : '<strong style="color:red">ОСТАНОВЛЕН</strong>';
        };

        o = s.option(form.Flag, 'enabled', _('Включить агента'));
        o.default = '1';
        o.rmempty = false;

        o = s.option(form.Value, 'token', _('Токен Telegram-бота'));
        o.password = true;
        o.placeholder = '123456789:AAxxxxxxxxxxxxxxxxxxxxxxxxxxxx';
        o.rmempty = false;

        o = s.option(form.Value, 'chat_id', _('User ID администратора бота'));
        o.placeholder = _('Оставьте пустым, сохраните и отправьте боту /start');
        o.rmempty = true;
        o.description = _('Один или несколько User ID администратора(-ов) Telegram-бота. Для получения User ID используйте @userinfobot или команду \'/myid\' в боте. Несколько ID можно указать через пробел, запятую или точку с запятой.');

        o = s.option(form.DynamicList, 'chat_ids', _('Дополнительные User ID администраторов'));
        o.placeholder = '111111111';
        o.rmempty = true;
        o.description = _('Дополнительные User ID Telegram-администраторов. Каждый пользователь может узнать свой ID командой /myid.');

        o = s.option(form.Value, 'router_name', _('Имя роутера'));
        o.placeholder = hostname;
        o.default = hostname;
        o.rmempty = false;
        o.cfgvalue = function(section_id) {
            return routerNameValue(section_id, hostname);
        };
        o.validate = function(section_id, value) {
            if (value && !/^[\x21-\x7E]+$/.test(value))
                return _('Имя роутера используется как один аргумент команды Telegram. Разрешены латиница, цифры и ASCII-спецсимволы без пробелов: _, -, ., @, # и т.п.');
            return true;
        };
        o.description = _('Имя используется в Telegram-командах как адрес роутера, например /status WBR3000UAX. При первом открытии подставляется hostname OpenWrt. Заглавные буквы сохраняются, NanoPiR3S не превращается в n_no_i.');

        o = s.option(form.ListValue, 'bot_mode', _('Режим Telegram-панели'));
        o.value('standalone', _('Один роутер / обычный режим'));
        o.value('panel', _('Главная панель нескольких роутеров'));
        o.value('worker', _('Worker-роутер без общих ответов'));
        o.default = 'standalone';
        o.rmempty = false;
        o.description = _('Для одного Telegram token на нескольких роутерах: на одном роутере выберите «Главная панель», на остальных — «Worker». Тогда /start и общие кнопки отвечает только панель, а worker отвечает только на команды со своим именем роутера.');

        o = s.option(form.Value, 'router_list', _('Роутеры в Telegram-панели'));
        o.depends('bot_mode', 'panel');
        o.placeholder = hostname + ' router2 router3 router4';
        o.rmempty = true;
        o.size = 96;
        o.cfgvalue = function(section_id) {
            return normalizeRouterList(uci.get('podkop_tg', section_id, 'router_list'));
        };
        o.write = function(section_id, value) {
            return uci.set('podkop_tg', section_id, 'router_list', normalizeRouterList(value));
        };
        o.description = _('Список имён роутеров для выбора кнопками в режиме панели. Это поле является источником кнопок: бот больше не добавляет третий роутер автоматически. Разделители: пробел, запятая или точка с запятой.');
        o.validate = function(section_id, value) {
            if (value && !/^[A-Za-z0-9_.@#:-]+([,;\s]+[A-Za-z0-9_.@#:-]+)*$/.test(value))
                return _('Используйте имена роутеров без пробелов внутри. Разделители: пробел, запятая или точка с запятой.');
            return true;
        };

        o = s.option(form.Value, 'router_aliases', _('Алиасы старых имён роутера'));
        o.placeholder = 'old-router-name rax';
        o.rmempty = true;
        o.size = 96;
        o.description = _('Необязательно. Нужны после переименования worker-роутера: бот будет отвечать и на старое имя из кнопок панели. Это помогает, если в поле «Роутеры в Telegram-панели» на главном роутере ещё осталось старое имя.');
        o.validate = function(section_id, value) {
            if (value && !/^[A-Za-z0-9_.@#:-]+([,;\s]+[A-Za-z0-9_.@#:-]+)*$/.test(value))
                return _('Используйте имена без пробелов внутри. Разделители: пробел, запятая или точка с запятой.');
            return true;
        };

        o = s.option(form.Flag, 'panel_send_header_on_actions', _('Картинка перед статусом/отчётом/помощью'));
        o.default = '1';
        o.rmempty = false;
        o.description = _('Если включено, при нажатии Статус, Отчёт и другие действия сначала отправляется картинка-шапка, затем текст команды. Помощь всегда выводится текстом без одиночной картинки.');

        o = s.option(form.Flag, 'header_image_enabled', _('Картинка-шапка над кнопками'));
        o.default = '1';
        o.rmempty = false;
        o.description = _('Если включено и файл картинки существует, бот отправляет картинку над главным меню с кнопками. Поддерживаются JPG/PNG/WebP. Если файла нет, бот работает как раньше.');

        o = s.option(form.Value, 'header_image_path', _('Путь к картинке-шапке'));
        o.placeholder = '/etc/podkop-telegram-agent/header.jpg';
        o.default = '/etc/podkop-telegram-agent/header.jpg';
        o.rmempty = false;
        o.description = _('Загрузите картинку на роутер по SSH/SCP, например: scp header.jpg root@192.168.2.1:/etc/podkop-telegram-agent/header.jpg. После замены картинки отправьте боту /start.');
        o.validate = function(section_id, value) {
            if (value && !/^\/.+\.(png|jpg|jpeg|webp)$/i.test(value))
                return _('Укажите абсолютный путь к файлу .png/.jpg/.jpeg/.webp, например /etc/podkop-telegram-agent/header.jpg');
            return true;
        };

        o = s.option(form.Value, 'podkop_section', _('Секция Podkop'));
        o.placeholder = 'main';
        o.default = 'main';
        o.rmempty = false;
        o.description = _('Секция по умолчанию для команды /update. Если в /update не указать секцию явно, vless/ss/trojan-ссылка будет загружена сюда. В отчёте эта секция помечается как «по умолчанию».');

        s = m.section(form.NamedSection, 'main', 'bot', _('Мониторинг и уведомления'));
        s.addremove = false;
        s.anonymous = true;

        o = s.option(form.Value, 'poll_timeout', _('Таймаут Telegram polling, сек'));
        o.datatype = 'uinteger';
        o.default = '10';
        o.rmempty = false;
        o.description = _('Чем меньше значение, тем быстрее приходят уведомления о падении. Рекомендуется 5–10 секунд.');

        o = s.option(form.Value, 'check_interval', _('Интервал проверки, сек'));
        o.datatype = 'uinteger';
        o.default = '10';
        o.rmempty = false;

        o = s.option(form.Value, 'foreign_hold_seconds', _('Удержание чужой команды, сек'));
        o.datatype = 'uinteger';
        o.default = '90';
        o.rmempty = false;
        o.description = _('Для нескольких роутеров в одном Telegram-боте: команда с чужим именем роутера не подтверждается сразу, чтобы нужный роутер успел её забрать. Если нужный роутер offline, очередь Telegram будет разблокирована после этого времени.');

        o = s.option(form.Value, 'log_lines', _('Количество строк логов'));
        o.datatype = 'uinteger';
        o.default = '200';
        o.rmempty = false;
        o.description = _('Для кнопки «📄 Посмотреть логи» и команды /logs. Если указано меньше 200, кнопка всё равно покажет минимум 200 строк.');

        o = s.option(form.Value, 'ping_host', _('Хост для проверки пинга'));
        o.placeholder = '1.1.1.1';
        o.default = '1.1.1.1';
        o.rmempty = false;

        o = s.option(form.Flag, 'alerts', _('Мгновенные уведомления'));
        o.default = '1';
        o.rmempty = false;
        o.description = _('Отправлять уведомление в Telegram, если Podkop или sing-box выключился/упал, и когда работа восстановилась.');

        o = s.option(form.Flag, 'alert_quiet_hours', _('Тихие часы уведомлений'));
        o.default = '1';
        o.rmempty = false;
        o.description = _('Авто-уведомления ночью можно отложить до утра или подавить. Ручные команды Telegram и ежедневный отчёт не блокируются.');

        o = s.option(form.Value, 'alert_quiet_start', _('Начало тихих часов'));
        o.depends('alert_quiet_hours', '1');
        o.placeholder = '23:00';
        o.default = '23:00';
        o.rmempty = false;
        o.validate = function(section_id, value) {
            if (!/^([01]?\d|2[0-3]):[0-5]\d$/.test(value || ''))
                return _('Укажите время в формате HH:MM, например 23:00.');
            return true;
        };

        o = s.option(form.Value, 'alert_quiet_end', _('Конец тихих часов'));
        o.depends('alert_quiet_hours', '1');
        o.placeholder = '08:00';
        o.default = '08:00';
        o.rmempty = false;
        o.validate = function(section_id, value) {
            if (!/^([01]?\d|2[0-3]):[0-5]\d$/.test(value || ''))
                return _('Укажите время в формате HH:MM, например 08:00.');
            return true;
        };

        o = s.option(form.ListValue, 'alert_quiet_mode', _('Режим тихих часов'));
        o.depends('alert_quiet_hours', '1');
        o.value('queue', _('Отложить до утра'));
        o.value('drop', _('Подавить уведомление'));
        o.default = 'queue';
        o.rmempty = false;
        o.description = _('queue — сохранить авто-уведомление и отправить после тихих часов. drop — не сохранять ночное авто-уведомление.');

        o = s.option(form.DummyValue, '_alert_quiet_state', _('Состояние тихих часов'));
        o.rawhtml = true;
        o.cfgvalue = function(section_id) {
            return '<code>' + quietStatusText(section_id) + '</code>';
        };

        o = s.option(form.Flag, 'daily_report', _('Ежедневный отчёт'));
        o.default = '1';
        o.rmempty = false;

        o = s.option(form.Value, 'daily_report_time', _('Время ежедневного отчёта'));
        o.placeholder = '09:00';
        o.default = '09:00';
        o.rmempty = false;
        o.description = _('Формат HH:MM, например 09:00. Отчёт отправляется один раз в день после наступления указанного времени, даже если агент был занят polling или перезапущен.');
        o.validate = function(section_id, value) {
            if (!/^([01]?\d|2[0-3]):[0-5]\d$/.test(value || ''))
                return _('Укажите время в формате HH:MM, например 09:00 или 21:30.');
            return true;
        };

        o = s.option(form.Flag, 'daily_backup', _('Отправлять backup OpenWrt с ежедневным отчётом'));
        o.default = '1';
        o.rmempty = false;
        o.description = _('Создаёт архив штатной командой sysupgrade -b и отправляет его файлом в Telegram после ежедневного отчёта. Внимание: backup содержит чувствительные настройки, ключи и токены. Включайте только для доверенного чата.');


        s = m.section(form.NamedSection, 'main', 'bot', _('Ограничение скорости'));
        s.addremove = false;
        s.anonymous = true;

        o = s.option(form.Flag, 'speed_control', _('Ограничение скорости устройств'));
        o.default = '1';
        o.rmempty = false;
        o.description = _('Включает Telegram-команды /speed, /speedset, /speedoff. Устройства берутся из статических DHCP-записей. Правила применяются через tc/HTB/fq_codel. Для upload используется IFB, если модуль доступен; fallback — tc police.');

        o = s.option(form.DummyValue, '_speed_hint', _('Команды Telegram'));
        o.rawhtml = true;
        o.cfgvalue = function(section_id) {
            var rn = normalizeRouterName(uci.get('podkop_tg', section_id, 'router_name') || 'openwrt');
            return '<code>/speed ' + rn + '</code><br />' +
                   '<code>/speedset ' + rn + ' 192.168.1.50 64kb</code><br />' +
                   '<code>/speedoff ' + rn + ' 192.168.1.50</code>';
        };

        s = m.section(form.NamedSection, 'main', 'bot', _('Управление сервисом'));
        s.addremove = false;
        s.anonymous = true;

        o = s.option(form.Button, '_restart', _('Перезапустить агент'));
        o.inputstyle = 'apply';
        o.onclick = function() {
            return m.save().then(function() {
                return serviceAction('restart');
            });
        };

        o = s.option(form.Button, '_viewlogs', _('📄 Посмотреть логи'));
        o.inputstyle = 'action';
        o.description = _('Открывает полный logread без фильтра: podkop, sing-box, telegram-agent, dnsmasq, uhttpd и остальные системные строки.');
        o.onclick = function() {
            return showAllLogs();
        };

        o = s.option(form.Button, '_start', _('Запустить агент'));
        o.inputstyle = 'save';
        o.onclick = function() {
            return m.save().then(function() {
                return serviceAction('start');
            });
        };

        o = s.option(form.Button, '_stop', _('Остановить агент'));
        o.inputstyle = 'reset';
        o.onclick = function() {
            return serviceAction('stop');
        };

        poll.add(function() {
            return serviceStatus().then(function(isRunning) {
                var node = document.querySelector('[data-name="_state"] .cbi-value-field');
                if (node)
                    node.innerHTML = isRunning
                        ? '<strong style="color:green">ЗАПУЩЕН</strong>'
                        : '<strong style="color:red">ОСТАНОВЛЕН</strong>';
            });
        });

        return m.render();
    }
});
