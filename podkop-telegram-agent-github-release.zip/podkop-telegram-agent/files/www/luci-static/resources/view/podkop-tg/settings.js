'use strict';

// INSTALL_LINK_RESTORE_V135: full package restore; install link works on clean router again.
// HELP_TEXT_FORCE_V134: Help button should send command list text.
// QUIET_HOURS_V132: quiet hours fields.
// URLTEST_REAL_FIX_V131: backend URLTest/VLESS fields kept.
'require view';
'require form';
'require fs';
'require ui';

function execCmd(cmd, args) {
    return fs.exec(cmd, args || []).then(function(res) {
        var out = (res.stdout || '') + (res.stderr || '');
        ui.addNotification(null, E('pre', { 'style': 'white-space:pre-wrap' }, out || 'OK'));
    }).catch(function(e) {
        ui.addNotification(null, E('pre', { 'style': 'white-space:pre-wrap' }, String(e)));
    });
}

return view.extend({
    render: function() {
        var m, s, o;
        m = new form.Map('podkop_tg', _('Podkop Telegram'), E('span', {}, [
            _('Podkop Telegram Agent v1.0.9 / INSTALL_LINK_RESTORE_V135'), E('br'),
            _('Полный пакет установки: /usr/bin, init.d, LuCI, config. Команда установки из README снова работает с чистого роутера.')
        ]));
        s = m.section(form.TypedSection, 'bot', _('Настройки бота'));
        s.anonymous = true;
        s.addremove = false;

        o = s.option(form.Flag, 'enabled', _('Включить агента'));
        o.default = '1';
        o.rmempty = false;

        o = s.option(form.Value, 'token', _('Telegram Bot Token'));
        o.password = true;
        o.rmempty = true;

        o = s.option(form.Value, 'chat_id', _('Telegram User ID администратора'));
        o.rmempty = true;

        o = s.option(form.DynamicList, 'admin_ids', _('Дополнительные админы'));
        o.rmempty = true;

        o = s.option(form.Value, 'router_name', _('Имя роутера для Telegram-команд'));
        o.placeholder = 'WBR3000UAX';
        o.rmempty = true;

        o = s.option(form.ListValue, 'bot_mode', _('Режим'));
        o.value('standalone', _('standalone — один роутер'));
        o.value('panel', _('panel — главный роутер'));
        o.value('worker', _('worker — роутер-исполнитель'));
        o.default = 'standalone';
        o.rmempty = false;

        o = s.option(form.DynamicList, 'routers', _('Роутеры панели'));
        o.rmempty = true;

        o = s.option(form.DynamicList, 'router_aliases', _('Алиасы этого роутера'));
        o.rmempty = true;

        o = s.option(form.Value, 'podkop_section', _('Секция Podkop по умолчанию'));
        o.placeholder = 'main';
        o.rmempty = true;

        o = s.option(form.Value, 'poll_timeout', _('Telegram poll timeout'));
        o.datatype = 'uinteger';
        o.default = '25';
        o.rmempty = false;

        o = s.option(form.Value, 'check_interval', _('Интервал авто-проверок, сек'));
        o.datatype = 'uinteger';
        o.default = '60';
        o.rmempty = false;

        o = s.option(form.Value, 'log_lines', _('Количество строк логов'));
        o.datatype = 'uinteger';
        o.default = '200';
        o.rmempty = false;

        o = s.option(form.Flag, 'alerts', _('Авто-уведомления'));
        o.default = '1';
        o.rmempty = false;

        o = s.option(form.Flag, 'alert_quiet_hours', _('Тихие часы уведомлений'));
        o.default = '1';
        o.rmempty = false;

        o = s.option(form.Value, 'alert_quiet_start', _('Начало тихих часов'));
        o.placeholder = '23:00';
        o.default = '23:00';
        o.rmempty = false;

        o = s.option(form.Value, 'alert_quiet_end', _('Конец тихих часов'));
        o.placeholder = '08:00';
        o.default = '08:00';
        o.rmempty = false;

        o = s.option(form.ListValue, 'alert_quiet_mode', _('Режим тихих часов'));
        o.value('queue', _('queue — отложить до утра'));
        o.value('drop', _('drop — подавить'));
        o.default = 'queue';
        o.rmempty = false;

        o = s.option(form.Flag, 'daily_report', _('Ежедневный отчёт'));
        o.default = '1';
        o.rmempty = false;

        o = s.option(form.Value, 'daily_report_time', _('Время ежедневного отчёта'));
        o.default = '09:00';
        o.rmempty = false;

        o = s.option(form.Flag, 'daily_backup', _('Прикладывать backup OpenWrt'));
        o.default = '1';
        o.rmempty = false;

        o = s.option(form.Flag, 'header_image_enabled', _('Картинка-шапка в меню'));
        o.default = '1';
        o.rmempty = false;

        o = s.option(form.Flag, 'panel_send_header_on_actions', _('Картинка при кнопках панели'));
        o.default = '1';
        o.rmempty = false;

        o = s.option(form.Value, 'header_image_path', _('Путь к картинке'));
        o.default = '/etc/podkop-telegram-agent/header.jpg';
        o.rmempty = false;

        o = s.option(form.ListValue, 'telegram_transport', _('Транспорт Telegram'));
        o.value('auto', 'auto');
        o.value('direct', 'direct');
        o.value('podkop', 'podkop');
        o.value('custom', 'custom proxy');
        o.default = 'auto';
        o.rmempty = false;

        o = s.option(form.Value, 'telegram_proxy', _('Custom proxy для Telegram'));
        o.placeholder = 'socks5h://127.0.0.1:2080';
        o.rmempty = true;

        o = s.option(form.Button, '_restart', _('Перезапустить агент'));
        o.inputstyle = 'save';
        o.onclick = function() { return execCmd('/etc/init.d/podkop-telegram-agent', ['restart']); };

        o = s.option(form.Button, '_status', _('Статус агента'));
        o.inputstyle = 'action';
        o.onclick = function() { return execCmd('/etc/init.d/podkop-telegram-agent', ['status']); };

        o = s.option(form.Button, '_logs', _('Показать логи'));
        o.inputstyle = 'action';
        o.onclick = function() { return execCmd('/usr/bin/podkop-telegram-agent-logread', ['300']); };

        return m.render();
    }
});
