#!/bin/sh
/etc/init.d/podkop-telegram-agent stop 2>/dev/null || true
/etc/init.d/podkop-telegram-agent disable 2>/dev/null || true
rm -f /usr/bin/podkop-telegram-agent /usr/bin/podkop-telegram-agent-logread /etc/init.d/podkop-telegram-agent
rm -f /usr/share/luci/menu.d/luci-app-podkop-tg.json /usr/share/rpcd/acl.d/luci-app-podkop-tg.json
rm -rf /www/luci-static/resources/view/podkop-tg /etc/podkop-telegram-agent
rm -rf /tmp/luci-indexcache /tmp/luci-modulecache /tmp/luci-*cache 2>/dev/null || true
/etc/init.d/rpcd restart 2>/dev/null || true
/etc/init.d/uhttpd restart 2>/dev/null || true
echo "Removed podkop-telegram-agent files. UCI config /etc/config/podkop_tg is kept."
