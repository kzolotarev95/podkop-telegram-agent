#!/bin/sh
# HELP_BUTTON_TEXT_FIX_V133_HOTFIX_INSTALLER
# Applies Podkop Telegram Agent v1.0.33 help-button hotfix over installed v1.0.32/v1.0.31 agent.
# OpenWrt/BusyBox ash compatible.

set -u

YES=0
for arg in "$@"; do
    case "$arg" in
        --yes|-y) YES=1 ;;
        --help|-h)
            cat <<'HELP'
podkop-telegram-agent help-button hotfix v1.0.33

Usage:
  ash install.sh --yes

What it changes:
  - fixes the Telegram ❓ Помощь button;
  - the Help button now sends the command list as text again;
  - /start remains image/menu only;
  - visible bot version stays Podkop Telegram Agent v1.0.9.
HELP
            exit 0
            ;;
    esac
done

log() { printf '%s\n' "$*"; }
warn() { printf 'WARN: %s\n' "$*" >&2; }
fail() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }
have() { command -v "$1" >/dev/null 2>&1; }

AGENT="/usr/bin/podkop-telegram-agent"
LUCI="/www/luci-static/resources/view/podkop-tg/settings.js"
STAMP="$(date +%Y%m%d-%H%M%S 2>/dev/null || echo now)"

[ "$YES" = "1" ] || fail "run with --yes"
[ -f /etc/openwrt_release ] || warn "/etc/openwrt_release not found; continuing anyway"
[ -f "$AGENT" ] || fail "$AGENT not found. Install podkop-telegram-agent first."

insert_before_text() {
    local file="$1" pat="$2" token="$3" add="$4" tmp
    grep -qF "$token" "$file" 2>/dev/null && return 0
    tmp="${file}.tmp.$$"
    awk -v pat="$pat" -v add="$add" '
        { if (!done && index($0, pat) > 0) { print add; done=1 } print }
        END { if (!done) exit 2 }
    ' "$file" > "$tmp" || { rm -f "$tmp"; return 1; }
    cat "$tmp" > "$file" && rm -f "$tmp"
}

patch_help_case() {
    local file="$1" tmp
    grep -qF 'send_help_commands_fixed "$chat"' "$file" 2>/dev/null && return 0
    tmp="${file}.tmp.$$"
    awk '
        {
            print
            if (!done && $0 ~ /^[[:space:]]*\/help\)/) {
                print "            send_help_commands_fixed \"$chat\""
                print "            return"
                done=1
            }
        }
        END { if (!done) exit 2 }
    ' "$file" > "$tmp" || { rm -f "$tmp"; return 1; }
    cat "$tmp" > "$file" && rm -f "$tmp"
}

patch_help_button_map() {
    local file="$1" tmp
    grep -qF 'HELP_BUTTON_TEXT_FIX_V133_MENU_MAP' "$file" 2>/dev/null && return 0
    tmp="${file}.tmp.$$"
    awk '
        {
            print
            if (!done && $0 ~ /^[[:space:]]*case "\$t" in/) {
                print "        \"❓ Помощь\"|\"Помощь\"|\"❔ Помощь\"|\"📘 Помощь\") echo \"/help\"; return ;; # HELP_BUTTON_TEXT_FIX_V133_MENU_MAP"
                done=1
            }
        }
        END { if (!done) exit 2 }
    ' "$file" > "$tmp" || { rm -f "$tmp"; return 1; }
    cat "$tmp" > "$file" && rm -f "$tmp"
}

patch_agent() {
    local backup funcs
    log "Patching $AGENT ..."
    backup="$AGENT.backup.help-v133.$STAMP"
    cp -a "$AGENT" "$backup" 2>/dev/null || true

    if ! grep -qF 'HELP_BUTTON_TEXT_FIX_V133' "$AGENT"; then
        sed -i '/QUIET_HOURS_V132/a # HELP_BUTTON_TEXT_FIX_V133: Help button sends command list as text, not header-only photo.' "$AGENT" 2>/dev/null || \
        sed -i '/URLTEST_REAL_FIX_V131/a # HELP_BUTTON_TEXT_FIX_V133: Help button sends command list as text, not header-only photo.' "$AGENT" 2>/dev/null || \
        sed -i '1a # HELP_BUTTON_TEXT_FIX_V133: Help button sends command list as text, not header-only photo.' "$AGENT" 2>/dev/null || true
    fi

    # Keep the visible LuCI/Telegram version from v1.0.32.
    sed -i 's/^BOT_VERSION=.*/BOT_VERSION="v1.0.9"/' "$AGENT" 2>/dev/null || true

    funcs=$(cat <<'FUNCS'
help_commands_text_fixed() {
    local router_html sec_html
    router_html="$(printf '%s' "$ROUTER_NAME" | escape_html)"
    sec_html="$(printf '%s' "${PODKOP_SECTION:-main}" | escape_html)"
    cat <<EOF_HELP_FIXED
<b>Podkop Telegram Agent ${BOT_VERSION}</b>
Роутер: <code>${router_html}</code>

<b>Основное:</b>
<code>/start</code> — меню
<code>/status ${router_html}</code> — статус
<code>/report ${router_html}</code> — полный отчёт
<code>/logs ${router_html} all 200</code> — логи
<code>/diag ${router_html}</code> — диагностика
<code>/health ${router_html}</code> — Tunnel Health
<code>/probe ${router_html}</code> — Active Outbound Probe
<code>/restart ${router_html}</code> — меню перезагрузки
<code>/backup ${router_html}</code> — backup OpenWrt
<code>/bundle ${router_html}</code> — support bundle
<code>/donate ${router_html}</code> — донат

<b>Podkop / URL:</b>
<code>/update ${router_html} vless://... ${sec_html}</code> — заменить proxy URL
<code>/urltest ${router_html}</code> — список URLTest/VLESS
<code>/urlping ${router_html}</code> — проверить серверы
<code>/urluse ${router_html} 1</code> — выбрать ссылку №1
<code>/urlteston ${router_html} ${sec_html}</code> — включить URLTest
<code>/urladd ${router_html} ${sec_html} vless://...</code> — добавить ссылку
<code>/urldel ${router_html} 1</code> — удалить ссылку
<code>/urlapply ${router_html}</code> — применить/restart Podkop
<code>/section ${router_html} ${sec_html}</code> — выбрать секцию
<code>/sections ${router_html}</code> — список секций

<b>Доступ устройств:</b>
<code>/access ${router_html}</code> — правила
<code>/accesshelp ${router_html}</code> — примеры
<code>/accessadd ${router_html} tv 192.168.1.50 14:00-20:00 mon-fri</code>
<code>/accessblock ${router_html} tv</code> — заблокировать
<code>/accessunblock ${router_html} tv</code> — снять блок
<code>/accessdel ${router_html} tv</code> — удалить правило

<b>Сервис:</b>
<code>/myid</code> — узнать Telegram ID
<code>/header ${router_html}</code> — проверить картинку
<code>/testreport ${router_html}</code> — тест ежедневного отчёта
<code>/botupdate ${router_html}</code> — обновить Telegram-бота
<code>/podkopupdate ${router_html}</code> — обновить Podkop
EOF_HELP_FIXED
    if command -v alert_quiet_summary >/dev/null 2>&1; then
        printf '\n%s\n' "$(alert_quiet_summary)"
    fi
}

send_help_commands_fixed() {
    local chat="$1" text resp rc
    [ -z "$TOKEN" ] && return 1
    [ -z "$chat" ] && return 1
    text="$(help_commands_text_fixed)"
    if command -v tg_curl >/dev/null 2>&1; then
        resp="$(tg_curl -sS --max-time 25 -X POST "$API/sendMessage" \
            --data-urlencode "chat_id=$chat" \
            --data-urlencode "text=$text" \
            --data-urlencode "parse_mode=HTML" \
            --data-urlencode "disable_web_page_preview=true" \
            --data-urlencode "reply_markup=$(keyboard_json)" 2>&1)"
        rc=$?
    else
        resp="$(curl -sS --max-time 25 -X POST "$API/sendMessage" \
            --data-urlencode "chat_id=$chat" \
            --data-urlencode "text=$text" \
            --data-urlencode "parse_mode=HTML" \
            --data-urlencode "disable_web_page_preview=true" \
            --data-urlencode "reply_markup=$(keyboard_json)" 2>&1)"
        rc=$?
    fi
    printf '%s\n' "$resp" >/tmp/podkop_tg_help_send.log
    [ "$rc" -eq 0 ] || { log "help send failed rc=$rc response=$(printf '%s' "$resp" | head -c 180)"; return 1; }
    printf '%s' "$resp" | grep -q '"ok"[[:space:]]*:[[:space:]]*true' && return 0
    if command -v jq >/dev/null 2>&1; then
        printf '%s' "$resp" | jq -e '.ok == true' >/dev/null 2>&1 && return 0
    fi
    log "help send unexpected response=$(printf '%s' "$resp" | head -c 180)"
    return 1
}
FUNCS
)

    insert_before_text "$AGENT" 'text_to_command() {' 'help_commands_text_fixed()' "$funcs" || \
    insert_before_text "$AGENT" 'handle_command() {' 'help_commands_text_fixed()' "$funcs" || \
    fail "could not insert help fix functions"

    patch_help_button_map "$AGENT" || warn "could not patch Help button text mapping; /help command is still fixed"
    patch_help_case "$AGENT" || fail "could not patch /help handler"

    chmod 0755 "$AGENT" 2>/dev/null || true
    if have ash; then
        if ! ash -n "$AGENT" >/tmp/podkop_tg_help_v133_syntax.log 2>&1; then
            warn "syntax check failed, restoring backup $backup"
            cp -a "$backup" "$AGENT" 2>/dev/null || true
            cat /tmp/podkop_tg_help_v133_syntax.log >&2 2>/dev/null || true
            fail "agent syntax check failed"
        fi
    fi
}

patch_luci() {
    [ -f "$LUCI" ] || return 0
    log "Marking $LUCI ..."
    cp -a "$LUCI" "$LUCI.backup.help-v133.$STAMP" 2>/dev/null || true
    grep -qF 'HELP_BUTTON_TEXT_FIX_V133' "$LUCI" || \
        sed -i '/QUIET_HOURS_V132/a // HELP_BUTTON_TEXT_FIX_V133: Telegram Help button sends command list text again.' "$LUCI" 2>/dev/null || true
    sed -i "s/var BOT_VERSION = 'v1.0.8';/var BOT_VERSION = 'v1.0.9';/" "$LUCI" 2>/dev/null || true
    chmod 0644 "$LUCI" 2>/dev/null || true
}

patch_agent
patch_luci

log "Clearing LuCI cache and restarting services ..."
rm -rf /tmp/luci-indexcache /tmp/luci-modulecache /tmp/luci-*cache 2>/dev/null || true
/etc/init.d/podkop-telegram-agent restart 2>/dev/null || true
/etc/init.d/rpcd restart 2>/dev/null || true
/etc/init.d/uhttpd restart 2>/dev/null || true

log ""
log "Installed help-button hotfix v1.0.33."
log "Check:"
log "  grep -n \"HELP_BUTTON_TEXT_FIX_V133\" /usr/bin/podkop-telegram-agent /www/luci-static/resources/view/podkop-tg/settings.js"
log "  /etc/init.d/podkop-telegram-agent status"
log "  logread | grep -Ei 'podkop-telegram-agent|podkop_tg|rpcd|uhttpd' | tail -n 250"
log "  logread -f"
