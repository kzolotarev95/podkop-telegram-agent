#!/bin/sh
# LUCIVIEW_FIX_V121: fixed LuCI settings.js require order for OpenWrt 24/25.
# OpenWrt/BusyBox ash compatible installer for podkop-telegram-agent.
# Safe for SSH install/update: preserves existing /etc/config/podkop_tg values by default.
# NO_OPKG_FIX_V2: installer works without opkg/apk when curl+jq already exist in firmware.
# ROUTER_NAME_FIX_V125: robust router hostname normalization; NanoPiR3S -> nanopir3s, RAX1 -> rax1.

CONFIG="podkop_tg"
SECTION="main"
SRC_BASE="${SRC_BASE:-}"
NON_INTERACTIVE="${NON_INTERACTIVE:-0}"
NO_START="${NO_START:-0}"
NO_LUCI_RELOAD="${NO_LUCI_RELOAD:-0}"
NO_DAILY_BACKUP="${NO_DAILY_BACKUP:-0}"
RESET_CONFIG="${RESET_CONFIG:-0}"
BOT_TOKEN="${BOT_TOKEN:-}"
CHAT_ID="${CHAT_ID:-}"
ROUTER_NAME="${ROUTER_NAME:-}"
PODKOP_SECTION="${PODKOP_SECTION:-}"
OPKG_UPDATED=0
DATE_TAG="$(date +%Y%m%d-%H%M%S 2>/dev/null || echo now)"

log() { printf '%s\n' "$*"; }
warn() { printf 'WARN: %s\n' "$*" >&2; }
fail() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }
have() { command -v "$1" >/dev/null 2>&1; }

usage() {
    cat <<'EOF_USAGE'
Usage: ash install.sh [options]

Options:
  -y, --yes, --non-interactive       Do not ask questions; keep existing UCI values.
  --token TOKEN                      Set real Telegram BotFather token (format: 123456:ABC...).
  --chat-id USER_IDS                 Set Telegram admin User ID(s), separated by space/comma/semicolon.
  --router-name NAME                 Set router name for Telegram commands, e.g. WBR3000UAX.
  --podkop-section SECTION           Set default Podkop section for /update.
  --reset-config                     Replace /etc/config/podkop_tg with package default before configure.
  --no-start                         Install files but do not restart the agent.
  --no-luci-reload                   Do not restart rpcd/uhttpd and do not clear LuCI cache.
  --no-daily-backup                  Do not auto-enable daily OpenWrt backup.
  -h, --help                         Show this help.

Environment variables are also supported:
  BOT_TOKEN, CHAT_ID, ROUTER_NAME, PODKOP_SECTION, NON_INTERACTIVE=1

Safe SSH update example:
  BOT_TOKEN="$(uci -q get podkop_tg.main.token)" \
  CHAT_ID="$(uci -q get podkop_tg.main.chat_id)" \
  ROUTER_NAME="$(uci -q get podkop_tg.main.router_name)" \
  ash install.sh --yes
EOF_USAGE
}

need_value() {
    [ -n "$2" ] || fail "missing value for $1"
}

while [ "$#" -gt 0 ]; do
    case "$1" in
        -y|--yes|--non-interactive)
            NON_INTERACTIVE=1
            ;;
        --token)
            shift; need_value --token "${1:-}"; BOT_TOKEN="$1"
            ;;
        --token=*)
            BOT_TOKEN="${1#--token=}"
            ;;
        --chat-id|--chat_id)
            shift; need_value --chat-id "${1:-}"; CHAT_ID="$1"
            ;;
        --chat-id=*|--chat_id=*)
            CHAT_ID="${1#*=}"
            ;;
        --router-name|--router_name)
            shift; need_value --router-name "${1:-}"; ROUTER_NAME="$1"
            ;;
        --router-name=*|--router_name=*)
            ROUTER_NAME="${1#*=}"
            ;;
        --podkop-section|--podkop_section)
            shift; need_value --podkop-section "${1:-}"; PODKOP_SECTION="$1"
            ;;
        --podkop-section=*|--podkop_section=*)
            PODKOP_SECTION="${1#*=}"
            ;;
        --reset-config)
            RESET_CONFIG=1
            ;;
        --no-start)
            NO_START=1
            ;;
        --no-luci-reload)
            NO_LUCI_RELOAD=1
            ;;
        --no-daily-backup)
            NO_DAILY_BACKUP=1
            ;;
        -h|--help)
            usage; exit 0
            ;;
        *)
            fail "unknown option: $1"
            ;;
    esac
    shift
 done

is_openwrt() {
    [ -f /etc/openwrt_release ] && return 0
    have opkg && [ -d /etc/config ] && return 0
    return 1
}

pkg_manager() {
    if have opkg; then
        printf '%s' opkg
        return 0
    fi
    if have apk; then
        printf '%s' apk
        return 0
    fi
    return 1
}

is_installed_pkg() {
    local mgr
    mgr="$(pkg_manager 2>/dev/null || true)"
    case "$mgr" in
        opkg) opkg list-installed "$1" 2>/dev/null | grep -q "^$1 " ;;
        apk) apk info -e "$1" >/dev/null 2>&1 ;;
        *) return 1 ;;
    esac
}

pkg_update_once() {
    local mgr
    [ "$OPKG_UPDATED" = "1" ] && return 0
    mgr="$(pkg_manager 2>/dev/null || true)"
    [ -n "$mgr" ] || return 1
    log "Updating OpenWrt package lists with $mgr..."
    case "$mgr" in
        opkg) opkg update || fail "opkg update failed. Check router internet/DNS, then retry." ;;
        apk) apk update || fail "apk update failed. Check router internet/DNS, then retry." ;;
        *) return 1 ;;
    esac
    OPKG_UPDATED=1
}

pkg_install() {
    local mgr
    mgr="$(pkg_manager 2>/dev/null || true)"
    [ -n "$mgr" ] || return 1
    case "$mgr" in
        opkg) opkg install "$@" ;;
        apk) apk add "$@" ;;
        *) return 1 ;;
    esac
}

install_required_deps() {
    local missing="" mgr

    have curl || missing="$missing curl"
    have jq || missing="$missing jq"

    mgr="$(pkg_manager 2>/dev/null || true)"
    if [ -n "$mgr" ]; then
        is_installed_pkg ca-bundle || missing="$missing ca-bundle"
        [ -z "$missing" ] && return 0
        log "Installing required packages with $mgr:$missing"
        pkg_update_once
        # shellcheck disable=SC2086
        pkg_install $missing || fail "failed to install required packages:$missing"
        return 0
    fi

    [ -z "$missing" ] || fail "missing required commands:$missing and no opkg/apk package manager found. Install curl and jq in firmware first."
    warn "opkg/apk not found; skipping package installation. Existing curl/jq will be used."
}

install_luci_deps() {
    local mgr
    [ -d /www/luci-static/resources ] || [ -d /usr/share/luci ] || return 0

    mgr="$(pkg_manager 2>/dev/null || true)"
    if [ -z "$mgr" ]; then
        warn "opkg/apk not found; cannot auto-install rpcd-mod-file. LuCI service buttons may not work if it is missing."
        return 0
    fi

    if ! is_installed_pkg rpcd-mod-file; then
        log "Installing optional LuCI package with $mgr: rpcd-mod-file"
        pkg_update_once || return 0
        pkg_install rpcd-mod-file || warn "rpcd-mod-file was not installed; LuCI service buttons may not work."
    fi
}

install_report_deps() {
    local mgr
    # Optional, used only for extended report Wi-Fi details.
    have iwinfo && return 0

    mgr="$(pkg_manager 2>/dev/null || true)"
    if [ -z "$mgr" ]; then
        warn "opkg/apk not found; cannot auto-install iwinfo. Report will work without Wi-Fi client details."
        return 0
    fi

    log "Installing optional report package with $mgr: iwinfo"
    pkg_update_once || return 0
    pkg_install iwinfo || warn "iwinfo was not installed; report will work without Wi-Fi client details."
}


backup_file() {
    local f="$1"
    [ -e "$f" ] || return 0
    cp -p "$f" "$f.backup.$DATE_TAG" 2>/dev/null || warn "could not backup $f"
}

copy_file() {
    local src="$1" dst="$2"
    [ -f "$src" ] || fail "missing package file: $src"
    mkdir -p "$(dirname "$dst")" || fail "cannot create directory for $dst"
    backup_file "$dst"
    cp "$src" "$dst" || fail "cannot copy $src to $dst"
}

fix_luci_permissions() {
    # LuCI/uhttpd returns HTTP 403 when static JS or menu/ACL JSON files are not
    # world-readable. Some zip builds preserved 0600 modes, so force safe modes.
    mkdir -p /www/luci-static/resources/view/podkop-tg /usr/share/luci/menu.d /usr/share/rpcd/acl.d 2>/dev/null || true
    chmod 0755         /www/luci-static         /www/luci-static/resources         /www/luci-static/resources/view         /www/luci-static/resources/view/podkop-tg         /usr/share/luci         /usr/share/luci/menu.d         /usr/share/rpcd         /usr/share/rpcd/acl.d 2>/dev/null || true
    chmod 0644         /www/luci-static/resources/view/podkop-tg/settings.js         /usr/share/luci/menu.d/luci-app-podkop-tg.json         /usr/share/rpcd/acl.d/luci-app-podkop-tg.json 2>/dev/null || true
}

copy_local_files() {
    [ -f ./files/usr/bin/podkop-telegram-agent ] || return 1

    if [ -x /etc/init.d/podkop-telegram-agent ]; then
        /etc/init.d/podkop-telegram-agent stop >/dev/null 2>&1 || true
    fi

    copy_file ./files/usr/bin/podkop-telegram-agent /usr/bin/podkop-telegram-agent
    copy_file ./files/usr/bin/podkop-telegram-agent-logread /usr/bin/podkop-telegram-agent-logread
    copy_file ./files/etc/init.d/podkop-telegram-agent /etc/init.d/podkop-telegram-agent

    if [ "$RESET_CONFIG" = "1" ]; then
        copy_file ./files/etc/config/podkop_tg /etc/config/podkop_tg
    elif [ ! -f /etc/config/podkop_tg ]; then
        mkdir -p /etc/config || fail "cannot create /etc/config"
        cp ./files/etc/config/podkop_tg /etc/config/podkop_tg || fail "cannot install /etc/config/podkop_tg"
    fi

    if [ -d /www/luci-static/resources ] || [ -d /usr/share/luci ]; then
        copy_file ./files/usr/share/luci/menu.d/luci-app-podkop-tg.json /usr/share/luci/menu.d/luci-app-podkop-tg.json
        copy_file ./files/usr/share/rpcd/acl.d/luci-app-podkop-tg.json /usr/share/rpcd/acl.d/luci-app-podkop-tg.json
        copy_file ./files/www/luci-static/resources/view/podkop-tg/settings.js /www/luci-static/resources/view/podkop-tg/settings.js
    else
        warn "LuCI not detected; installed CLI/service files only."
    fi

    fix_luci_permissions

    mkdir -p /etc/podkop-telegram-agent || warn "cannot create /etc/podkop-telegram-agent"
    [ -f /etc/podkop-telegram-agent/access_rules.conf ] || : > /etc/podkop-telegram-agent/access_rules.conf
    [ -f /etc/podkop-telegram-agent/access_manual.conf ] || : > /etc/podkop-telegram-agent/access_manual.conf
    chmod 0600 /etc/podkop-telegram-agent/access_rules.conf /etc/podkop-telegram-agent/access_manual.conf 2>/dev/null || true
    # Install compact default header image. Older custom PNGs can be large and
    # trigger curl (26) on small OpenWrt builds, so use a small JPG by default.
    if [ -f ./files/etc/podkop-telegram-agent/header.jpg ]; then
        if [ ! -s /etc/podkop-telegram-agent/header.jpg ]; then
            cp ./files/etc/podkop-telegram-agent/header.jpg /etc/podkop-telegram-agent/header.jpg || warn "cannot install default header.jpg"
            log "Default JPG header installed: /etc/podkop-telegram-agent/header.jpg"
        else
            log "Existing JPG header preserved: /etc/podkop-telegram-agent/header.jpg"
        fi
    fi
    # Keep PNG too for users who explicitly select it later, but do not force it.
    if [ -f ./files/etc/podkop-telegram-agent/header.png ] && [ ! -s /etc/podkop-telegram-agent/header.png ]; then
        cp ./files/etc/podkop-telegram-agent/header.png /etc/podkop-telegram-agent/header.png || true
    fi
    chmod 0755 /usr/bin/podkop-telegram-agent /usr/bin/podkop-telegram-agent-logread /etc/init.d/podkop-telegram-agent || fail "cannot chmod installed files"
    chmod 0644 /etc/podkop-telegram-agent/header.jpg /etc/podkop-telegram-agent/header.png 2>/dev/null || true
    return 0
}

download_file() {
    local url="$1" dst="$2"
    mkdir -p "$(dirname "$dst")" || fail "cannot create directory for $dst"
    backup_file "$dst"
    if have curl; then
        curl -fsSL --connect-timeout 10 --max-time 60 -o "$dst" "$url" || fail "download failed: $url"
    elif have wget; then
        wget -qO "$dst" "$url" || fail "download failed: $url"
    else
        fail "curl or wget is required for remote install"
    fi
}

copy_remote_files() {
    [ -n "$SRC_BASE" ] || return 1
    warn "Local ./files directory was not found; downloading from SRC_BASE=$SRC_BASE"

    if [ -x /etc/init.d/podkop-telegram-agent ]; then
        /etc/init.d/podkop-telegram-agent stop >/dev/null 2>&1 || true
    fi

    download_file "$SRC_BASE/files/usr/bin/podkop-telegram-agent" /usr/bin/podkop-telegram-agent
    download_file "$SRC_BASE/files/usr/bin/podkop-telegram-agent-logread" /usr/bin/podkop-telegram-agent-logread
    download_file "$SRC_BASE/files/etc/init.d/podkop-telegram-agent" /etc/init.d/podkop-telegram-agent

    if [ "$RESET_CONFIG" = "1" ] || [ ! -f /etc/config/podkop_tg ]; then
        download_file "$SRC_BASE/files/etc/config/podkop_tg" /etc/config/podkop_tg
    fi

    mkdir -p /etc/podkop-telegram-agent || warn "cannot create /etc/podkop-telegram-agent"
    [ -f /etc/podkop-telegram-agent/access_rules.conf ] || : > /etc/podkop-telegram-agent/access_rules.conf
    [ -f /etc/podkop-telegram-agent/access_manual.conf ] || : > /etc/podkop-telegram-agent/access_manual.conf
    chmod 0600 /etc/podkop-telegram-agent/access_rules.conf /etc/podkop-telegram-agent/access_manual.conf 2>/dev/null || true
    if [ ! -s /etc/podkop-telegram-agent/header.jpg ]; then
        if [ -n "$SRC_BASE" ]; then
            download_file "$SRC_BASE/files/etc/podkop-telegram-agent/header.jpg" /etc/podkop-telegram-agent/header.jpg || true
        fi
    fi
    if [ ! -s /etc/podkop-telegram-agent/header.png ]; then
        if [ -n "$SRC_BASE" ]; then
            download_file "$SRC_BASE/files/etc/podkop-telegram-agent/header.png" /etc/podkop-telegram-agent/header.png || true
        fi
    fi
    fix_luci_permissions
    chmod 0755 /usr/bin/podkop-telegram-agent /usr/bin/podkop-telegram-agent-logread /etc/init.d/podkop-telegram-agent || fail "cannot chmod installed files"
    chmod 0644 /etc/podkop-telegram-agent/header.jpg /etc/podkop-telegram-agent/header.png 2>/dev/null || true
}

uci_get() {
    uci -q get "$1" 2>/dev/null || true
}

uci_set_if_empty() {
    local key="$1" val="$2" cur
    cur="$(uci_get "$key")"
    [ -n "$cur" ] && return 0
    [ -z "$val" ] && return 0
    uci set "$key=$val"
}

is_interactive() {
    [ "$NON_INTERACTIVE" = "1" ] && return 1
    [ -t 0 ] && return 0
    return 1
}

normalize_router_name() {
    # ASCII uppercase is lowered before filtering: NanoPiR3S -> nanopir3s, RAX1 -> rax1.
    local n
    n="$(printf '%s' "$1" | sed 'y/ABCDEFGHIJKLMNOPQRSTUVWXYZ/abcdefghijklmnopqrstuvwxyz/' | tr '[:space:]' '_' | sed 's/[^a-z0-9_.@#:-]/_/g;s/_\{1,\}/_/g;s/^_//;s/_$//')"
    [ -z "$n" ] && n="openwrt"
    printf '%s' "$n"
}

system_router_hostname() {
    local h
    h="$(ubus call system board 2>/dev/null | sed -n 's/.*\"hostname\"[[:space:]]*:[[:space:]]*\"\([^\"]*\)\".*/\1/p' | head -n 1)"
    [ -n "$h" ] || h="$(cat /proc/sys/kernel/hostname 2>/dev/null | head -n 1)"
    [ -n "$h" ] || h="$(hostname 2>/dev/null | head -n 1)"
    [ -n "$h" ] || h="openwrt"
    printf '%s' "$h"
}

is_bad_router_name() {
    local n="$1" hn hnorm
    [ -z "$n" ] && return 0
    hn="$(system_router_hostname 2>/dev/null || true)"
    hnorm="$(normalize_router_name "$hn")"
    case "$n" in
        openwrt|OpenWrt|OPENWRT|o__nwrt|o--nwrt|o_nwrt|localhost|router|Router|n_no_i|r_x1|ano_i_3|1) return 0 ;;
    esac
    [ -n "$hnorm" ] && [ "$hnorm" != "openwrt" ] && [ "$n" = "openwrt" ] && return 0
    return 1
}

append_router_alias() {
    local alias="$1" cur x out seen
    [ -n "$alias" ] || return 0
    is_bad_router_name "$alias" && return 0
    cur="$(uci_get "$CONFIG.$SECTION.router_aliases")"
    out=""
    seen=" "
    for x in $cur $alias; do
        [ -n "$x" ] || continue
        [ "$x" = "$ROUTER_NAME" ] && continue
        case "$seen" in *" $x "*) continue ;; esac
        out="$out $x"
        seen="$seen$x "
    done
    out="$(printf '%s' "$out" | sed 's/^ *//;s/ *$//')"
    [ -n "$out" ] && uci set "$CONFIG.$SECTION.router_aliases=$out"
}

is_placeholder_token() {
    case "$1" in
        ''|TELEGRAM_BOT_TOKEN|BOT_TOKEN|YOUR_BOT_TOKEN|PASTE_TOKEN_HERE|TOKEN|xxx|XXX|'<TOKEN>'|'CHANGE_ME')
            return 0
            ;;
    esac
    return 1
}

valid_bot_token() {
    local token id secret
    token="$1"
    is_placeholder_token "$token" && return 1
    case "$token" in
        *:*) ;;
        *) return 1 ;;
    esac
    id="${token%%:*}"
    secret="${token#*:}"
    case "$id" in
        ''|*[!0-9]*) return 1 ;;
    esac
    [ ${#secret} -ge 20 ] || return 1
    return 0
}

valid_section_name() {
    [ -n "$1" ] || return 1
    uci -q show "podkop.$1" >/dev/null 2>&1
}

detect_proxy_section() {
    local sec
    sec="$(uci -q show podkop 2>/dev/null | sed -n "s/^podkop\.\([^.=]*\)\.connection_type='proxy'.*/\1/p" | head -n 1)"
    [ -n "$sec" ] && { printf '%s' "$sec"; return 0; }
    sec="$(uci -q show podkop 2>/dev/null | sed -n "s/^podkop\.\([^.=]*\)\.proxy_string=.*/\1/p" | head -n 1)"
    [ -n "$sec" ] && { printf '%s' "$sec"; return 0; }
    return 1
}

configure_uci() {
    local old_token old_chat old_router old_section old_aliases host typed detected selected_section

    uci -q get "$CONFIG.$SECTION" >/dev/null 2>&1 || uci set "$CONFIG.$SECTION=bot"

    old_token="$(uci_get "$CONFIG.$SECTION.token")"
    old_chat="$(uci_get "$CONFIG.$SECTION.chat_id")"
    old_router="$(uci_get "$CONFIG.$SECTION.router_name")"
    old_aliases="$(uci_get "$CONFIG.$SECTION.router_aliases")"
    old_section="$(uci_get "$CONFIG.$SECTION.podkop_section")"

    if [ -n "$old_token" ] && ! valid_bot_token "$old_token"; then
        warn "Existing Telegram token in UCI looks like a placeholder/invalid value; it will not be reused."
        old_token=""
        uci -q delete "$CONFIG.$SECTION.token" 2>/dev/null || true
    fi

    if [ -n "$BOT_TOKEN" ] && ! valid_bot_token "$BOT_TOKEN"; then
        warn "Ignoring invalid --token/BOT_TOKEN value. Use the real BotFather token, not the example TELEGRAM_BOT_TOKEN."
        BOT_TOKEN=""
    fi

    [ -z "$BOT_TOKEN" ] && BOT_TOKEN="$old_token"
    [ -z "$CHAT_ID" ] && CHAT_ID="$old_chat"
    [ -z "$ROUTER_NAME" ] && ROUTER_NAME="$old_router"
    if is_bad_router_name "$ROUTER_NAME"; then
        [ -n "$ROUTER_NAME" ] && [ "$ROUTER_NAME" != "openwrt" ] && old_aliases="$old_aliases $ROUTER_NAME"
        ROUTER_NAME=""
    fi
    [ -z "$PODKOP_SECTION" ] && PODKOP_SECTION="$old_section"

    if [ -z "$BOT_TOKEN" ] && is_interactive; then
        log "Telegram token can be entered later in LuCI: Services -> Podkop Telegram."
        printf 'Telegram bot token now (empty = configure later in LuCI): '
        read -r BOT_TOKEN
    fi

    if [ -z "$CHAT_ID" ] && is_interactive; then
        printf "Telegram User ID администратора (empty = bind first /start): "
        read -r CHAT_ID
    fi

    if [ -n "$BOT_TOKEN" ] && ! valid_bot_token "$BOT_TOKEN"; then
        warn "Telegram token format looks invalid; leaving token empty. Paste the real BotFather token in LuCI or rerun with --token."
        BOT_TOKEN=""
        uci -q delete "$CONFIG.$SECTION.token" 2>/dev/null || true
    fi

    if [ -z "$ROUTER_NAME" ]; then
        host="$(system_router_hostname 2>/dev/null || true)"
        [ -z "$host" ] && host="openwrt"
        ROUTER_NAME="$host"
        if is_interactive; then
            printf 'Имя роутера для Telegram-команд [%s]: ' "$ROUTER_NAME"
            read -r typed
            [ -n "$typed" ] && ROUTER_NAME="$typed"
        fi
    fi
    ROUTER_NAME="$(normalize_router_name "$ROUTER_NAME")"
    if [ -n "$old_router" ] && [ "$old_router" != "$ROUTER_NAME" ] && ! is_bad_router_name "$old_router"; then
        old_aliases="$old_aliases $old_router"
    fi

    detected="$(detect_proxy_section || true)"
    selected_section="$PODKOP_SECTION"

    case "$selected_section" in
        ''|auto)
            selected_section="$detected"
            ;;
        *)
            if ! valid_section_name "$selected_section"; then
                warn "Podkop section '$selected_section' does not exist. Auto-detected section: ${detected:-main}."
                selected_section="$detected"
            fi
            ;;
    esac

    [ -z "$selected_section" ] && selected_section="main"

    uci set "$CONFIG.$SECTION.enabled=1"
    [ -n "$BOT_TOKEN" ] && uci set "$CONFIG.$SECTION.token=$BOT_TOKEN"
    [ -n "$CHAT_ID" ] && uci set "$CONFIG.$SECTION.chat_id=$CHAT_ID"
    [ -n "$ROUTER_NAME" ] && uci set "$CONFIG.$SECTION.router_name=$ROUTER_NAME"
    if [ -n "$old_aliases" ]; then
        uci set "$CONFIG.$SECTION.router_aliases=$(printf '%s' "$old_aliases" | tr ',;\n\t' '    ' | awk -v rn="$ROUTER_NAME" 'BEGIN{seen=" "} {for(i=1;i<=NF;i++){if($i==rn) continue; if(index(seen," "$i" ")==0){out=out (out?" ":"") $i; seen=seen $i " "}}} END{print out}')"
    fi
    [ -n "$selected_section" ] && uci set "$CONFIG.$SECTION.podkop_section=$selected_section"

    uci_set_if_empty "$CONFIG.$SECTION.poll_timeout" "25"
    uci_set_if_empty "$CONFIG.$SECTION.check_interval" "60"
    uci_set_if_empty "$CONFIG.$SECTION.log_lines" "40"
    uci_set_if_empty "$CONFIG.$SECTION.alerts" "1"

    # Daily report must work out of the box after SSH install/update.
    # Keep the user's chosen time, but ensure the feature is enabled automatically.
    uci set "$CONFIG.$SECTION.daily_report=1"
    uci_set_if_empty "$CONFIG.$SECTION.daily_report_time" "09:00"
    if [ "$NO_DAILY_BACKUP" = "1" ]; then
        uci_set_if_empty "$CONFIG.$SECTION.daily_backup" "0"
    else
        uci set "$CONFIG.$SECTION.daily_backup=1"
    fi

    uci_set_if_empty "$CONFIG.$SECTION.header_image_enabled" "1"
    uci_set_if_empty "$CONFIG.$SECTION.panel_send_header_on_actions" "1"
    uci_set_if_empty "$CONFIG.$SECTION.header_image_path" "/etc/podkop-telegram-agent/header.jpg"
    # Auto-migrate previous PNG default to compact JPG. This fixes curl (26)
    # on OpenWrt when an oversized PNG was preserved from older builds.
    old_header_path="$(uci_get "$CONFIG.$SECTION.header_image_path")"
    if [ "$old_header_path" = "/etc/podkop-telegram-agent/header.png" ] && [ -s /etc/podkop-telegram-agent/header.jpg ]; then
        uci set "$CONFIG.$SECTION.header_image_path=/etc/podkop-telegram-agent/header.jpg"
    fi
    uci_set_if_empty "$CONFIG.$SECTION.ping_host" "1.1.1.1"
    uci_set_if_empty "$CONFIG.$SECTION.foreign_hold_seconds" "90"
    uci_set_if_empty "$CONFIG.$SECTION.device_control" "1"

    uci commit "$CONFIG" || fail "uci commit $CONFIG failed"
}

reload_luci() {
    [ "$NO_LUCI_RELOAD" = "1" ] && return 0

    rm -rf /tmp/luci-indexcache /tmp/luci-modulecache /tmp/luci-*cache 2>/dev/null || true

    if [ -x /etc/init.d/rpcd ]; then
        /etc/init.d/rpcd restart >/dev/null 2>&1 || warn "rpcd restart failed"
    fi
    if [ -x /etc/init.d/uhttpd ]; then
        /etc/init.d/uhttpd reload >/dev/null 2>&1 || /etc/init.d/uhttpd restart >/dev/null 2>&1 || warn "uhttpd reload/restart failed"
    fi
}

start_service() {
    [ "$NO_START" = "1" ] && return 0

    /etc/init.d/podkop-telegram-agent enable >/dev/null 2>&1 || warn "could not enable podkop-telegram-agent"

    # Some OpenWrt/procd combinations print "Command failed: Not found" on restart
    # when the old instance is not registered yet. Keep SSH install output clean and
    # fall back to explicit stop/start.
    if ! /etc/init.d/podkop-telegram-agent restart >/dev/null 2>&1; then
        /etc/init.d/podkop-telegram-agent stop >/dev/null 2>&1 || true
        /etc/init.d/podkop-telegram-agent start >/dev/null 2>&1 || warn "could not start podkop-telegram-agent"
    fi

    sleep 1
    /etc/init.d/podkop-telegram-agent status >/dev/null 2>&1 || warn "podkop-telegram-agent is not reported as running; check: logread -e podkop-telegram-agent"
}

print_summary() {
    local token_set chat router section
    token_set="no"
    if valid_bot_token "$(uci_get "$CONFIG.$SECTION.token")"; then
        token_set="yes"
    fi
    chat="$(uci_get "$CONFIG.$SECTION.chat_id")"
    router="$(uci_get "$CONFIG.$SECTION.router_name")"
    section="$(uci_get "$CONFIG.$SECTION.podkop_section")"

    log ""
    log "Installed podkop-telegram-agent."
    log "Token set: $token_set"
    log "Admin User ID(s): ${chat:-not set; first /start can bind admin if empty}"
    log "Router name: ${router:-openwrt}"
    log "Default Podkop section: ${section:-main}"
    log "Daily report: $(uci_get "$CONFIG.$SECTION.daily_report") at $(uci_get "$CONFIG.$SECTION.daily_report_time")"
    log "Daily OpenWrt backup: $(uci_get "$CONFIG.$SECTION.daily_backup")"
    log "Menu image header: $(uci_get "$CONFIG.$SECTION.header_image_enabled") at $(uci_get "$CONFIG.$SECTION.header_image_path")"
    log "Bot mode: $(uci_get "$CONFIG.$SECTION.bot_mode")"
    log "Router list: $(uci_get "$CONFIG.$SECTION.router_list")"
    log ""
    log "Check over SSH:"
    log "  /etc/init.d/podkop-telegram-agent status"
    log "  logread -e podkop-telegram-agent | tail -n 80"
    log "  uci show podkop_tg | sed \"s/token='[^']*'/token='***'/\""
    log ""
    log "Telegram commands:"
    log "  /status ${router:-openwrt}"
    log "  /diag ${router:-openwrt}"
    log "  /report ${router:-openwrt}"
    log "  /backup ${router:-openwrt}"
    log "  /testreport ${router:-openwrt}"
    log "  /donate ${router:-openwrt}"
}

main() {
    log "Installer build: no-opkg-fix-v2"
    is_openwrt || fail "this installer is for OpenWrt and must be run on the router via SSH"
    [ "$(id -u 2>/dev/null || echo 1)" = "0" ] || fail "run as root"
    have uci || fail "uci not found; this does not look like OpenWrt"

    install_required_deps
    install_luci_deps
    install_report_deps

    copy_local_files || copy_remote_files || fail "package files not found. Run from the unpacked archive directory or set SRC_BASE."
    configure_uci
    reload_luci
    start_service
    print_summary
}

main "$@"
