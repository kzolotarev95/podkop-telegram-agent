#!/bin/sh
# INSTALL_LINK_RESTORE_V135_FULL_PACKAGE
# Full OpenWrt installer/updater. Safe: preserves /etc/config/podkop_tg unless --reset-config is used.

CONFIG="podkop_tg"
SECTION="main"
ASSUME_YES=0
RESET_CONFIG=0
for a in "$@"; do
    case "$a" in
        --yes|-y) ASSUME_YES=1 ;;
        --reset-config) RESET_CONFIG=1 ;;
    esac
done

log() { printf '%s\n' "$*"; }
warn() { printf 'WARN: %s\n' "$*" >&2; }
fail() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }
have() { command -v "$1" >/dev/null 2>&1; }

is_installed() {
    if have opkg; then opkg list-installed "$1" 2>/dev/null | grep -q "^$1 "; return $?; fi
    if have apk; then apk info -e "$1" >/dev/null 2>&1; return $?; fi
    return 1
}

install_pkg() {
    p="$1"
    is_installed "$p" && return 0
    if have opkg; then opkg update >/dev/null 2>&1 || true; opkg install "$p" >/dev/null 2>&1 || return 1; return 0; fi
    if have apk; then apk add "$p" >/dev/null 2>&1 || return 1; return 0; fi
    return 1
}

ensure_deps() {
    have uci || fail "uci not found; this installer must run on OpenWrt"
    have curl || install_pkg curl || fail "curl not found and cannot be installed"
    have jq || install_pkg jq || fail "jq not found and cannot be installed"
    install_pkg ca-bundle >/dev/null 2>&1 || true
    if [ -d /www/luci-static/resources ] || [ -d /usr/share/luci ]; then
        install_pkg rpcd-mod-file >/dev/null 2>&1 || warn "rpcd-mod-file was not installed; LuCI buttons may be limited"
    fi
}

copy_file() {
    src="$1"; dst="$2"; mode="$3"
    [ -f "$src" ] || fail "package is incomplete: $src not found"
    mkdir -p "$(dirname "$dst")" || fail "cannot create $(dirname "$dst")"
    cp "$src" "$dst" || fail "cannot copy $src to $dst"
    [ -n "$mode" ] && chmod "$mode" "$dst" 2>/dev/null || true
}

install_files() {
    [ -f ./files/usr/bin/podkop-telegram-agent ] || fail "bad archive: files/usr/bin/podkop-telegram-agent missing"
    [ -f ./files/etc/init.d/podkop-telegram-agent ] || fail "bad archive: files/etc/init.d/podkop-telegram-agent missing"

    copy_file ./files/usr/bin/podkop-telegram-agent /usr/bin/podkop-telegram-agent 0755
    copy_file ./files/usr/bin/podkop-telegram-agent-logread /usr/bin/podkop-telegram-agent-logread 0755
    copy_file ./files/etc/init.d/podkop-telegram-agent /etc/init.d/podkop-telegram-agent 0755

    mkdir -p /etc/podkop-telegram-agent
    [ -f ./files/etc/podkop-telegram-agent/header.jpg ] && copy_file ./files/etc/podkop-telegram-agent/header.jpg /etc/podkop-telegram-agent/header.jpg 0644

    if [ "$RESET_CONFIG" = "1" ] || [ ! -f /etc/config/podkop_tg ]; then
        copy_file ./files/etc/config/podkop_tg /etc/config/podkop_tg 0644
    fi

    if [ -d /www/luci-static/resources ] || [ -d /usr/share/luci ]; then
        copy_file ./files/usr/share/luci/menu.d/luci-app-podkop-tg.json /usr/share/luci/menu.d/luci-app-podkop-tg.json 0644
        copy_file ./files/usr/share/rpcd/acl.d/luci-app-podkop-tg.json /usr/share/rpcd/acl.d/luci-app-podkop-tg.json 0644
        copy_file ./files/www/luci-static/resources/view/podkop-tg/settings.js /www/luci-static/resources/view/podkop-tg/settings.js 0644
    else
        warn "LuCI not detected; installed CLI/service files only"
    fi
}

get_host() {
    h="$(cat /proc/sys/kernel/hostname 2>/dev/null | head -n 1)"
    [ -n "$h" ] || h="$(hostname 2>/dev/null | head -n 1)"
    [ -n "$h" ] || h="openwrt"
    printf '%s' "$h" | tr '[:space:]' '_' | sed 's/[^A-Za-z0-9_.@#:-]/_/g;s/_\{1,\}/_/g;s/^_//;s/_$//'
}

uciset_if_empty() {
    opt="$1"; val="$2"
    cur="$(uci -q get "$CONFIG.$SECTION.$opt" 2>/dev/null)"
    [ -n "$cur" ] || uci set "$CONFIG.$SECTION.$opt=$val"
}

configure_defaults() {
    uci -q get "$CONFIG.$SECTION" >/dev/null 2>&1 || uci set "$CONFIG.$SECTION=bot"
    uciset_if_empty enabled 1
    uciset_if_empty bot_mode standalone
    uciset_if_empty router_name "$(get_host)"
    uciset_if_empty podkop_section main
    uciset_if_empty poll_timeout 25
    uciset_if_empty check_interval 60
    uciset_if_empty log_lines 200
    uciset_if_empty alerts 1
    uciset_if_empty alert_quiet_hours 1
    uciset_if_empty alert_quiet_start '23:00'
    uciset_if_empty alert_quiet_end '08:00'
    uciset_if_empty alert_quiet_mode queue
    uciset_if_empty daily_report 1
    uciset_if_empty daily_report_time '09:00'
    uciset_if_empty daily_backup 1
    uciset_if_empty header_image_enabled 1
    uciset_if_empty panel_send_header_on_actions 1
    uciset_if_empty header_image_path '/etc/podkop-telegram-agent/header.jpg'
    uciset_if_empty ping_host '1.1.1.1'
    uciset_if_empty foreign_hold_seconds 90
    uciset_if_empty device_control 1
    uciset_if_empty telegram_transport auto

    if [ -n "$BOT_TOKEN" ]; then uci set "$CONFIG.$SECTION.token=$BOT_TOKEN"; fi
    if [ -n "$CHAT_ID" ]; then uci set "$CONFIG.$SECTION.chat_id=$CHAT_ID"; fi
    if [ -n "$ROUTER_NAME" ]; then uci set "$CONFIG.$SECTION.router_name=$ROUTER_NAME"; fi

    if [ "$ASSUME_YES" != "1" ]; then
        token="$(uci -q get "$CONFIG.$SECTION.token" 2>/dev/null)"
        chat="$(uci -q get "$CONFIG.$SECTION.chat_id" 2>/dev/null)"
        if [ -z "$token" ]; then
            printf 'Telegram bot token now (empty = configure later in LuCI): '
            read -r token_in
            [ -n "$token_in" ] && uci set "$CONFIG.$SECTION.token=$token_in"
        fi
        if [ -z "$chat" ]; then
            printf 'Telegram User ID администратора (empty = bind first /start): '
            read -r chat_in
            [ -n "$chat_in" ] && uci set "$CONFIG.$SECTION.chat_id=$chat_in"
        fi
    fi
    uci commit "$CONFIG"
}

reload_luci() {
    rm -rf /tmp/luci-indexcache /tmp/luci-modulecache /tmp/luci-*cache 2>/dev/null || true
    [ -x /etc/init.d/rpcd ] && /etc/init.d/rpcd restart >/dev/null 2>&1 || true
    [ -x /etc/init.d/uhttpd ] && { /etc/init.d/uhttpd reload >/dev/null 2>&1 || /etc/init.d/uhttpd restart >/dev/null 2>&1 || true; }
}

main() {
    [ "$(id -u 2>/dev/null || echo 1)" = "0" ] || fail "run as root"
    log "podkop-telegram-agent full installer"
    log "Marker: INSTALL_LINK_RESTORE_V135_FULL_PACKAGE"
    ensure_deps
    install_files
    configure_defaults
    reload_luci
    /etc/init.d/podkop-telegram-agent enable >/dev/null 2>&1 || true
    /etc/init.d/podkop-telegram-agent restart >/dev/null 2>&1 || true
    log "Installed podkop-telegram-agent."
    log "Token set: $( [ -n "$(uci -q get podkop_tg.main.token 2>/dev/null)" ] && echo yes || echo no )"
    log "Admin User ID(s): $(uci -q get podkop_tg.main.chat_id 2>/dev/null)"
    log "Router name: $(uci -q get podkop_tg.main.router_name 2>/dev/null)"
    log "Default Podkop section: $(uci -q get podkop_tg.main.podkop_section 2>/dev/null)"
}
main "$@"
