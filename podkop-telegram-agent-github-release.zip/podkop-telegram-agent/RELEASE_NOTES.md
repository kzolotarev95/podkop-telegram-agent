## v1.0.33 - Help button text fix

- Fixed Telegram `❓ Помощь` button returning only the header image in some builds.
- Help now sends a compact HTML command list as text again.
- `/start` remains image/menu only.
- Visible bot version stays `Podkop Telegram Agent v1.0.9`.
