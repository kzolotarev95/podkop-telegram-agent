## v1.0.35 - restore full one-link installer

- Restored full GitHub root archive layout for clean OpenWrt installation.
- Fixed previous hotfix-only archive failure: `ERROR: /usr/bin/podkop-telegram-agent not found`.
- Root installer validates package layout before running inner installer.
- Preserves existing UCI config and token/chat_id values during updates.
- Visible version remains `Podkop Telegram Agent v1.0.9`.

## v1.0.34 - help text force

- `/help` and `❓ Помощь` send text command list, not only header image.

## v1.0.32 - quiet hours for alerts

- Added configurable quiet hours for automatic alerts, default `23:00-08:00`, mode `queue`.
