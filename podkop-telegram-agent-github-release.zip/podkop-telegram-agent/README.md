# podkop-telegram-agent

Latest fix: v1.0.33 — Telegram Help button text fix.

Видимая версия в интерфейсе: **Podkop Telegram Agent v1.0.9**

## Что исправлено

Кнопка `❓ Помощь` снова выводит список команд текстом, как раньше.
`/start` остаётся чистым меню с картинкой/кнопками.
