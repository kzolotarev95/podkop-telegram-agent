# podkop-telegram-agent

Latest fix: v1.0.14 — fixed parental-control IP parsing and old malformed block rules.

Версия: **v1.0.7**

Telegram-модуль для Podkop/OpenWrt.

Агент работает отдельной службой OpenWrt, управляется через UCI-конфиг:

```sh
/etc/config/podkop_tg
```

Веб-морда LuCI: **Services → Podkop Telegram**.

## Возможности

- Telegram-панель для одного или нескольких роутеров.
- Режимы:
  - `standalone` — один роутер.
  - `panel` — главный роутер с Telegram-панелью и выбором роутеров.
  - `worker` — второй/третий роутер, который отвечает только на команды своего имени.
- Команды `/status`, `/report`, `/diag`, `/logs`, `/restart`, `/backup`, `/access`, `/urltest`, `/urlping`, `/urluse`.
- Расширенный отчёт: температура, RAM, SWAP, overlay/flash, модель, OpenWrt, kernel, Podkop, sing-box, WAN, Wi-Fi, DHCP/Wi-Fi клиенты.
- Уведомления о WAN/Internet DOWN, восстановлении, reboot, Podkop/sing-box событиях.
- Очередь уведомлений: если интернет упал и Telegram недоступен, уведомления уйдут после восстановления.
- Картинка-шапка меню: `/etc/podkop-telegram-agent/header.jpg`.
- LuCI-модуль с настройками.
- Backup OpenWrt через `sysupgrade -b`.
- Управление доступом устройств / родительский контроль: блокировка статических IP по расписанию через отдельную firewall-таблицу, совместимо с OpenWrt 24/25.
- Управление Podkop URLTest/VLESS: список ссылок из UCI, добавление/удаление, применение выбранной ссылки, возврат секции в URLTest, проверка доступности серверов по TCP.

## Зависимости

Минимально:

```sh
opkg update
opkg install curl jq ca-bundle unzip tar gzip
```

Для расширенного отчёта с Wi-Fi-информацией:

```sh
opkg install iwinfo
```


Если на сборке нет `opkg`, но есть `apk`:

```sh
apk update
apk add curl jq ca-bundle unzip tar gzip rpcd-mod-file iwinfo
```

Если нет ни `opkg`, ни `apk`, ставьте архив `.tar.gz`; `curl` и `jq` должны быть уже встроены в прошивку.
Для LuCI-кнопок и веб-морды:

```sh
opkg install rpcd-mod-file
```

Если на чистом роутере нет LuCI:

```sh
opkg install luci
/etc/init.d/uhttpd enable
/etc/init.d/uhttpd restart
```

Установщик `install.sh` сам попробует поставить `curl`, `jq`, `ca-bundle`, `rpcd-mod-file` и `iwinfo`, если они доступны через `opkg` или `apk`. Если пакетного менеджера нет, установщик продолжит только при уже установленных `curl` и `jq`.


### Установка на сборках без opkg/unzip

Если на роутере нет `opkg` или `unzip`, используйте `.tar.gz`:

```sh
cd /tmp
rm -f podkop-telegram-agent.tar.gz
rm -rf /tmp/podkop-telegram-agent

wget -O podkop-telegram-agent.tar.gz https://github.com/kzolotarev95/podkop-telegram-agent/releases/latest/download/podkop-telegram-agent-github-release.tar.gz

tar -xzf podkop-telegram-agent.tar.gz -C /tmp
cd /tmp/podkop-telegram-agent

grep -n "NO_OPKG_FIX_V2" install.sh
ash install.sh --yes
```

Если нет пакетного менеджера, `curl` и `jq` должны быть уже встроены в прошивку.

## Установка с нуля из архива

Скопировать архив на роутер:

```sh
scp podkop-telegram-agent-github-release.zip root@192.168.2.1:/tmp/
```

На роутере:

```sh
opkg update
opkg install curl jq ca-bundle unzip tar gzip rpcd-mod-file iwinfo

cd /tmp
rm -rf /tmp/podkop-telegram-agent

unzip -o /tmp/podkop-telegram-agent-github-release.zip -d /tmp
cd /tmp/podkop-telegram-agent

ash install.sh --yes
```

Настроить UCI:

```sh
uci set podkop_tg.main.enabled='1'
uci set podkop_tg.main.token='TELEGRAM_BOT_TOKEN'
uci set podkop_tg.main.chat_id='5361341623'
uci set podkop_tg.main.router_name='WBR3000UAX'
uci set podkop_tg.main.podkop_section='main'
uci commit podkop_tg

/etc/init.d/podkop-telegram-agent enable
/etc/init.d/podkop-telegram-agent restart
```

Проверка:

```sh
/etc/init.d/podkop-telegram-agent status
uci show podkop_tg | sed "s/token='[^']*'/token='***'/"
logread -e podkop-telegram-agent | tail -n 120
logread -e podkop | tail -n 80
logread -e sing-box | tail -n 80
```

## Установка с передачей параметров сразу

```sh
ash install.sh --yes \
  --token 'TELEGRAM_BOT_TOKEN' \
  --chat-id '5361341623' \
  --router-name 'WBR3000UAX' \
  --podkop-section 'main'
```

## Multi-router режим

Один роутер должен быть `panel`, остальные `worker`.

На главном роутере:

```sh
uci set podkop_tg.main.bot_mode='panel'
uci set podkop_tg.main.router_name='WBR3000UAX'
uci set podkop_tg.main.router_list='WBR3000UAX AX3000T'
uci commit podkop_tg
/etc/init.d/podkop-telegram-agent restart
```

На втором роутере:

```sh
uci set podkop_tg.main.bot_mode='worker'
uci set podkop_tg.main.router_name='AX3000T'
uci set podkop_tg.main.router_list='WBR3000UAX AX3000T'
uci commit podkop_tg
/etc/init.d/podkop-telegram-agent restart
```

Важно: если два роутера с одним Telegram token будут в режиме `panel`, будут дубли сообщений.

## Telegram-команды

```text
/start
/status ROUTER
/report ROUTER
/diag ROUTER
/health ROUTER
/logs ROUTER
/logs ROUTER 500
/logs ROUTER runtime
/logs ROUTER errors
/logs ROUTER singbox
/logs ROUTER podkop
/restart ROUTER
/backup ROUTER
/access ROUTER
/accesshelp ROUTER
/accessadd ROUTER tv 192.168.1.50 14:00-20:00 mon-fri
/accessadd ROUTER tv 192.168.1.50 14:00-20:00 mon-fri aa:bb:cc:dd:ee:ff
/accessblock ROUTER tv
/accessunblock ROUTER tv
/accessdel ROUTER tv
/accessapply ROUTER
/accesson ROUTER
/accessoff ROUTER
/testreport ROUTER
/header ROUTER
/myid
/help
```

## Управление доступом устройств / родительский контроль

Функция нужна, чтобы ограничивать интернет для ТВ-приставок, консолей и других устройств по расписанию. Лучше всего использовать уже настроенные статические DHCP-адреса.

Бот не трогает `PodkopTable`, `/etc/sing-box/config.json` и настройки Podkop. Он создаёт отдельную firewall-таблицу:

```sh
inet podkop_tg_access
```

На OpenWrt 24/25 используется `nft/firewall4`, fallback — `iptables`. Если MAC устройства найден в `/tmp/dhcp.leases` или static DHCP, он используется дополнительно к IPv4-блокировке.

Примеры:

```text
/access ROUTER
/accesshelp ROUTER
/accessadd ROUTER tv 192.168.1.50 14:00-20:00 mon-fri
/accessadd ROUTER tv2 192.168.1.51 22:00-07:00 all
/accessblock ROUTER tv
/accessunblock ROUTER tv
/accessdel ROUTER tv
/accessapply ROUTER
```

Включить функцию:

```sh
uci set podkop_tg.main.device_control='1'
uci commit podkop_tg
/etc/init.d/podkop-telegram-agent restart
```

Проверить firewall-правила:

```sh
nft list table inet podkop_tg_access 2>/dev/null
iptables -L PODKOP_TG_ACCESS -n -v 2>/dev/null
```


## Backup бота без токена

Чтобы сделать backup установленного бота со всеми настройками, но без Telegram token:

```sh
ash scripts/backup-no-token.sh
```

Архив появится в `/tmp`:

```sh
ls -lh /tmp/podkop-telegram-agent-backup-no-token-*.tar.gz
```

Проверить, что token пустой:

```sh
tar -xOzf /tmp/podkop-telegram-agent-backup-no-token-*.tar.gz ./etc/config/podkop_tg | grep token
```

## Восстановление backup без токена на чистом роутере

На новом роутере:

```sh
opkg update
opkg install curl jq ca-bundle unzip tar gzip rpcd-mod-file iwinfo

cd /
tar -xzpf /tmp/podkop-telegram-agent-backup-no-token-*.tar.gz

chmod 0755 /usr/bin/podkop-telegram-agent
chmod 0755 /usr/bin/podkop-telegram-agent-logread
chmod 0755 /etc/init.d/podkop-telegram-agent
chmod 0644 /etc/config/podkop_tg
chmod 0644 /usr/share/luci/menu.d/luci-app-podkop-tg.json 2>/dev/null
chmod 0644 /usr/share/rpcd/acl.d/luci-app-podkop-tg.json 2>/dev/null
chmod 0644 /www/luci-static/resources/view/podkop-tg/settings.js 2>/dev/null
chmod 0644 /etc/podkop-telegram-agent/* 2>/dev/null
```

Потом обязательно прописать новый token и имя роутера:

```sh
uci set podkop_tg.main.token='TELEGRAM_BOT_TOKEN'
uci set podkop_tg.main.router_name='AX3000T'
uci set podkop_tg.main.podkop_section='main'
uci commit podkop_tg

/etc/init.d/podkop-telegram-agent enable
/etc/init.d/podkop-telegram-agent restart
```

## Сброс LuCI-кэша

```sh
rm -rf /tmp/luci-indexcache /tmp/luci-modulecache /tmp/luci-*cache
/etc/init.d/rpcd restart
/etc/init.d/uhttpd restart
```

## Логи

```sh
logread -e podkop-telegram-agent | tail -n 160
logread -e podkop | tail -n 80
logread -e sing-box | tail -n 80
logread | tail -n 160
```

## Безопасность

Не публикуй настоящий Telegram token. В репозитории держи `option token ''`, а token вводи только на роутере через UCI или LuCI.


## Device access / parental control

Added Telegram commands for device access control by static IPv4 address. The bot can block TV boxes, consoles or other devices by schedule using OpenWrt firewall (`nft`, fallback `iptables`).

Examples:

```sh
/access ROUTER
/accessadd ROUTER tv 192.168.1.50 14:00-20:00 mon-fri
/accessblock ROUTER tv
/accessunblock ROUTER tv
/accessdel ROUTER tv
/accessapply ROUTER
```

Use static DHCP leases for controlled devices so their IP addresses do not change.


## v1.0.5 additions

- `👨‍👩‍👧 Родительский Контроль` now shows only one help button instead of a keyboard full of raw commands.
- `🔄 Рестарт` opens two modes: `Reboot Podkop` and `Reboot Router`.
- `⬆️ Обновить Podkop` downloads and runs the itdoginfo/podkop installer on the selected router.
- Bot version is visible in the Telegram menu/help.


## v1.0.6 fix

- Блокировка устройств теперь применяется в prerouting до Podkop/TProxy, поэтому работает и для трафика, который уходит через Podkop/sing-box.
- Reboot Router выполняется через ubus/system reboot с fallback на /sbin/reboot.
- Видимая версия в Telegram: Podkop Telegram Agent v1.0.4.


## v1.0.7 fix

- В меню доступа устройств кнопка `📘 Помощь по командам` и `🔙 Меню` теперь стоят в одной строке.
- Видимая версия бота обновлена до `Podkop Telegram Agent v1.0.5`.
- Версия добавлена не только в `/status`, но и в `/report`.
- Из стартового меню убрана строка `Нажми ❓ Помощь, чтобы открыть список команд`.
## v1.0.12 fix

- В разделе `👨‍👩‍👧 Родительский Контроль` добавлена кнопка `📌 Активные блокировки ROUTER`.
- Кнопка `🔙 Меню` заменена на `🔙 Назад`.
- Добавлена команда `/accessblocked ROUTER` для отдельного вывода заблокированных устройств.
- Видимая версия в Telegram: `Podkop Telegram Agent v1.0.7`.



## v1.0.13 fix
- Видимая версия в Telegram: `Podkop Telegram Agent v1.0.7`.
- Кнопка `🚫 Доступ устройств` переименована в `👨‍👩‍👧 Родительский Контроль`.
- Раздел активных блокировок теперь показывает только реально заблокированные устройства.
- Усилена блокировка: добавлены nft bridge и netdev ingress правила поверх ранних inet pre-Podkop/TProxy правил.


### Podkop Telegram Agent v1.10.10

Quiet hours for automatic notifications: default `23:00-08:00`, mode `queue` (`отложить до утра`) or `drop` (`подавить`). Reports show whether quiet hours are active now.
