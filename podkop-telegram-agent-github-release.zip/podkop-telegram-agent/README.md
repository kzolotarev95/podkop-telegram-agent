# podkop-telegram-agent

Latest fix: v1.0.35 — restore full one-link installer.

Версия в интерфейсе: **Podkop Telegram Agent v1.0.9**

## Установка в один клик

```sh
wget -O- https://raw.githubusercontent.com/kzolotarev95/podkop-telegram-agent/main/install.sh | ash -s -- --yes
```

## Что исправлено в v1.0.35

- Архив `podkop-telegram-agent-github-release.tar.gz` снова полный, а не patch-only.
- Установка работает на чистом роутере, где ещё нет `/usr/bin/podkop-telegram-agent`.
- Root installer проверяет наличие `files/usr/bin/podkop-telegram-agent` и `files/etc/init.d/podkop-telegram-agent` до запуска внутреннего installer.
- Сохраняются существующие `/etc/config/podkop_tg`, token, chat_id, router_name.
- Сохранены маркеры: `URLTEST_REAL_FIX_V131`, `QUIET_HOURS_V132`, `HELP_TEXT_FORCE_V134`.

## Проверка

```sh
grep -nE "INSTALL_LINK_RESTORE_V135|HELP_TEXT_FORCE_V134|QUIET_HOURS_V132|URLTEST_REAL_FIX_V131"   /usr/bin/podkop-telegram-agent /www/luci-static/resources/view/podkop-tg/settings.js

/etc/init.d/podkop-telegram-agent status
logread -e podkop-telegram-agent | tail -n 160
logread -f
```
